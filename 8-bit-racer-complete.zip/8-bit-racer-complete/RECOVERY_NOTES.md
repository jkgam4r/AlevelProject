# Recovery Notes

## What was available

The supplied archive contained the Python source tree and a 342-page development document, but did not contain the runtime `assets/` or `data/` directories shown in the documentation.

The documentation and source together were enough to recover the expected structure and schemas:

- `assets/AI/blue_car`
- `assets/audio/buttonpress`, `click`, `confirmation`, `keypress`, `menu_music`
- `assets/redcar/car`, `carleft`, `carright`
- `assets/tiles/0` through `4`
- `data/tracks/`
- `data/users/`
- `data/masterlist.json`

The documented tile meanings are:

- `0` — road
- `1` — grass
- `2` — off-road
- `3` — barrier
- `4` — start/finish
- `5` — checkpoint (drawn procedurally as yellow by the game)

The final track format is a 64 x 36 integer grid plus creator, name, optional AI data and records. The final user format stores username, salted password hash, personal records, and music/SFX settings.

## What was reconstructed

### Graphics

New original pixel-style replacements were created for all required tile and car images. They match the dimensions and usage expected by the code. They are not the lost originals.

### Audio

New simple chiptune-style menu music and UI sound effects were synthesized for the exact filenames/formats expected by the code:

- `click.wav`
- `keypress.ogg`
- `confirmation.ogg`
- `buttonpress.ogg`
- `menu_music.mp3`

### Tracks

The exact original track JSON files were not present, so their tile-by-tile layouts cannot be recovered reliably. Eight new compatible tracks were therefore created. Each is 64 x 36, has the hard-coded start/finish line expected by the game, contains exactly three checkpoints, and has a connected drivable route. Seven contain AI waypoint data; one intentionally has AI disabled to exercise both code paths.

Some track names were chosen from names visible in the old project documentation, but the layouts are new recovery replacements.

### Users

The historical user JSON files shown in the documentation were not present. Passwords and personal records therefore cannot be reconstructed. A local `demo` profile was created solely for testing. New users can be created normally in-game.

## Portability/code repairs

The original project was written around Windows-style current-working-directory paths. The recovery adds `paths.py` and converts runtime asset/data access to paths rooted at the project folder, making the build portable to the new Mac as well as Windows/Linux.

The missing font dependency was removed in favour of a pygame monospace/default fallback.

The AI file no longer requires NumPy for basic trigonometry; it uses Python's standard `math` module instead. This reduces setup to a single third-party package (`pygame`).

The audio handler now degrades gracefully if pygame cannot initialize an audio device.

The track-builder AI waypoint generator was also hardened. The original left-wall traversal could collapse into a tiny local loop on wider roads; the recovered version derives a connected route through the fixed start tile and all three checkpoints, so reconstructed or newly saved wider tracks do not produce unusable one-point AI data.

## Validation performed

The recovered source has been Python-compiled successfully. The reconstructed data has also been checked for:

- required files present
- valid JSON
- 64 x 36 track dimensions
- only supported tile IDs
- exact required start/finish location
- exactly three checkpoints per track
- connected drivable tiles
- AI waypoints landing on drivable tiles
- masterlist paths resolving to real track files
- demo password authentication against the project's own hashing logic
- construction of every screen using a pygame API test double
- loading/drawing every reconstructed track through `GameScreen.set_prev()`
- end-of-race personal/global record JSON write/read behaviour
- TrackBuilder load/save/masterlist behaviour, including reloading the saved track into the race with AI enabled

The execution environment used for the recovery does not have pygame installed and cannot download packages, so a real graphical pygame session could not be launched here. `verify_recovery.py` is included specifically so the static/data checks can be repeated on the destination machine before launch.
