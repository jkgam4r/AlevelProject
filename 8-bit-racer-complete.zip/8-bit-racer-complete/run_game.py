"""Portable launcher for 8 Bit Racer."""
from pathlib import Path
import sys

MAIN_FOLDER = Path(__file__).resolve().parent / "main_folder"
sys.path.insert(0, str(MAIN_FOLDER))

import pygame
from main import main

if __name__ == "__main__":
    try:
        main()
    finally:
        pygame.quit()
