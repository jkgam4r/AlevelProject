"""Static integrity check for the reconstructed 8 Bit Racer project.

This deliberately does not import pygame, so it can be run before dependencies
are installed.
"""
from __future__ import annotations

from collections import deque
from pathlib import Path
import json
import py_compile
import sys

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / "main_folder"
ASSETS = ROOT / "assets"
DATA = ROOT / "data"

REQUIRED_ASSETS = [
    ASSETS / "redcar" / "car.png",
    ASSETS / "redcar" / "carleft.png",
    ASSETS / "redcar" / "carright.png",
    ASSETS / "AI" / "blue_car.png",
    *(ASSETS / "tiles" / f"{n}.png" for n in range(5)),
    ASSETS / "audio" / "click.wav",
    ASSETS / "audio" / "keypress.ogg",
    ASSETS / "audio" / "confirmation.ogg",
    ASSETS / "audio" / "buttonpress.ogg",
    ASSETS / "audio" / "menu_music.mp3",
]


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def validate_track(path: Path) -> None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"Cannot parse {path.name}: {exc}")

    for key in ("track", "creator", "name", "AI", "records"):
        if key not in data:
            fail(f"{path.name} is missing key {key!r}")

    grid = data["track"]
    if len(grid) != 36 or any(len(row) != 64 for row in grid):
        fail(f"{path.name} must contain a 36 x 64 tile grid")

    if any(tile not in {0, 1, 2, 3, 4, 5} for row in grid for tile in row):
        fail(f"{path.name} contains an unknown tile type")

    start_line = [(y, x) for y, row in enumerate(grid) for x, v in enumerate(row) if v == 4]
    expected_start = [(25, 33), (26, 33), (27, 33), (28, 33)]
    if start_line != expected_start:
        fail(f"{path.name} has an incompatible start/finish line")

    checkpoints = [(y, x) for y, row in enumerate(grid) for x, v in enumerate(row) if v == 5]
    if len(checkpoints) != 3:
        fail(f"{path.name} must contain exactly 3 checkpoints")

    drivable = {(y, x) for y, row in enumerate(grid) for x, v in enumerate(row) if v in {0, 4, 5}}
    if not drivable:
        fail(f"{path.name} has no drivable tiles")

    queue = deque([next(iter(drivable))])
    visited = {queue[0]}
    while queue:
        y, x = queue.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            neighbour = (y + dy, x + dx)
            if neighbour in drivable and neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)
    if visited != drivable:
        fail(f"{path.name} contains disconnected drivable track tiles")

    ai = data["AI"]
    if ai is not None:
        if not isinstance(ai, list) or len(ai) != 2 or not isinstance(ai[1], list) or len(ai[1]) < 2:
            fail(f"{path.name} has malformed AI data")
        for waypoint in ai[1]:
            if not isinstance(waypoint, list) or len(waypoint) != 2:
                fail(f"{path.name} contains a malformed AI waypoint")
            y, x = waypoint
            if not (0 <= y < 36 and 0 <= x < 64 and grid[y][x] in {0, 4, 5}):
                fail(f"{path.name} has an AI waypoint outside the drivable track: {waypoint}")


def main() -> int:
    missing = [str(path.relative_to(ROOT)) for path in REQUIRED_ASSETS if not path.is_file()]
    if missing:
        fail("Missing required assets: " + ", ".join(missing))

    for source in MAIN.rglob("*.py"):
        try:
            py_compile.compile(str(source), doraise=True)
        except py_compile.PyCompileError as exc:
            fail(f"Python compilation failed for {source.relative_to(ROOT)}: {exc}")

    master_path = DATA / "masterlist.json"
    if not master_path.is_file():
        fail("data/masterlist.json is missing")
    master = json.loads(master_path.read_text(encoding="utf-8"))
    listed = master.get("masterlist")
    if not isinstance(listed, list) or len(listed) < 4:
        fail("masterlist.json must list at least four tracks")

    seen = set()
    for rel in listed:
        if not isinstance(rel, str):
            fail("masterlist contains a non-string track path")
        track_path = ROOT / rel.replace("\\", "/")
        if not track_path.is_file():
            fail(f"Masterlist points to missing track: {rel}")
        validate_track(track_path)
        seen.add(track_path.resolve())

    track_files = {p.resolve() for p in (DATA / "tracks").glob("*.json")}
    if seen != track_files:
        fail("masterlist.json and data/tracks do not contain the same set of tracks")

    print(f"[OK] {len(REQUIRED_ASSETS)} required assets found")
    print(f"[OK] {len(track_files)} tracks validated (64 x 36, connected, 3 checkpoints)")
    print("[OK] All Python files compile")
    print("[OK] Recovery integrity check passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
