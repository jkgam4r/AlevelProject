import pygame
from paths import ASSETS_DIR

pygame.init()


class AudioManager():
    """Small audio facade used by the existing screens.

    The original build assumed an audio device and Windows-relative paths.
    The restored version keeps the same public methods but degrades gracefully
    to silent mode if a mixer/audio device is unavailable.
    """

    def __init__(self):
        self.music = True
        self.SFX = True
        self.audio_available = False
        self.click = None
        self.keysound = None
        self.success = None
        self.buttonsound = None

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()

            audio_dir = ASSETS_DIR / "audio"
            self.click = pygame.mixer.Sound(str(audio_dir / "click.wav"))
            self.keysound = pygame.mixer.Sound(str(audio_dir / "keypress.ogg"))
            self.success = pygame.mixer.Sound(str(audio_dir / "confirmation.ogg"))
            self.buttonsound = pygame.mixer.Sound(str(audio_dir / "buttonpress.ogg"))
            pygame.mixer.music.load(str(audio_dir / "menu_music.mp3"))
            pygame.mixer.music.play(-1)
            self.audio_available = True
        except (pygame.error, OSError):
            # Keep the game usable on machines/headless sessions without audio.
            self.audio_available = False

    def _play(self, sound):
        if self.audio_available and self.SFX and sound is not None:
            sound.play()

    def clicksound(self):
        self._play(self.click)

    def keypress(self):
        self._play(self.keysound)

    def SuccessSound(self):
        self._play(self.success)

    def ButtonPress(self):
        self._play(self.buttonsound)

    def ChangeMusic(self):
        self.music = not self.music

    def ChangeSFX(self):
        self.SFX = not self.SFX

    def update(self):
        if not self.audio_available:
            return
        if not self.music:
            pygame.mixer.music.pause()
        elif not pygame.mixer.music.get_busy():
            pygame.mixer.music.unpause()


GlobalAudio = AudioManager()
