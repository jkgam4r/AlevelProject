current_user = '' 

def get_user():
    return current_user
    
def set_user(user):
    global current_user
    current_user = user
    return True

