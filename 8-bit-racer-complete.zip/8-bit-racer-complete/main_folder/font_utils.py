"""Font helper used by the restored project.

The original project bundled Press Start 2P.  The restored build deliberately
uses a system monospace font (with pygame's default as fallback) so it has no
external font-file dependency and remains portable.
"""
import pygame


def game_font(size):
    try:
        font = pygame.font.SysFont("monospace", int(size), bold=True)
        if font is not None:
            return font
    except Exception:
        pass
    return pygame.font.Font(None, int(size))
