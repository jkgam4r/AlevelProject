import pygame
from UIElements.UIButton import UI_Button
from UIElements.UITextbox import UI_Textbox
from screens.screen import Screen
from data_layer import create_user, load_user
from user_functions import set_user
from audio_handler import GlobalAudio

class newuserscreen(Screen):
    def __init__(self, updatestate):
        super().__init__((60,60,60))

        self.update_state = updatestate

        self.message = ''  #placeholder for message to be displayed after create new user button pressed
        self.tickssincepressed = 300   #ticks since button was pressed

        def returntomenu():
            self.update_state("EXIST/NEW")

            self.usernamebox.text = ''
            self.passwordbox.text = ''
            self.repeatpasswordbox.text = ''

        def createnew():
            username = self.usernamebox.text
            password1 = self.passwordbox.text  #get text stored in buttons
            password2 = self.repeatpasswordbox.text

            if password1 == password2:  #if passwords match
                result = create_user(username, password1)  #try to create a new user profile using these

                if result == "SUCCESS":   #handling results from create_user
                    set_user(self.usernamebox.text)
                    self.message = 'User Created, Logged in as ' + self.usernamebox.text

                    user_dict = load_user(self.usernamebox.text)  #gets the user dict

                    musicstate = user_dict[1]["settings"]["music"]  #fetch user stored music state 
                    SFXstate = user_dict[1]["settings"]["SFX"]  #user stored SFX state
                
                    if musicstate != GlobalAudio.music:  #if the stored state is not the current state
                        GlobalAudio.ChangeMusic()  #then flip the state
                    if SFXstate != GlobalAudio.SFX:  #if stored sfx not current sfx
                        GlobalAudio.ChangeSFX()   #flip sfx state

                    GlobalAudio.SuccessSound()  #play success sound

                        
                elif result == "USERNAME_TAKEN":
                    self.message = 'Username Taken, Try again'
                elif result == "WEAK_PASSWROD":
                    self.message = "Password Weak, Try a stronger password"
                elif result == "INVALID_INPUT":
                    self.message = 'Invalid Input'
                else:
                    self.message = 'An unexpected error has occured'

                self.tickssincepressed = 0
                return
                
            else:
                self.message = "These Passwords do NOT match"   #message if the passwords don't match
                self.tickssincepressed = 0
                return


        returnbutton = UI_Button(20, 20, 150, 60, "Return", returntomenu, (255,0,0), (255,255,0))
        createuserbutton = UI_Button(20, 450, 595, 50, "Create New User", createnew, (255,0,0), (255,255,0))
        
        self.usernamebox = UI_Textbox(20, 180, 595, 50, "", "Enter Username", 20, False)  #current users box
        self.passwordbox = UI_Textbox(20, 280, 595, 50, "", "Enter Password", 20, True) #current user password box
        self.repeatpasswordbox = UI_Textbox(20, 380, 595, 50, "", "Repeat Password", 20, True)


    

        self.add([returnbutton, self.usernamebox, self.passwordbox, self.repeatpasswordbox, createuserbutton])
    
    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour

        pygame.draw.rect(surface, (120, 120, 120), (620, 85, 660, 635))  #lighten section for rules part

        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen
        

        self.draw_text(surface, "New Users Create Login Here", 30, 230, 40, True, (0,0,0))   #user text
        self.draw_text(surface, "Username & Password Rules :", 20, 630, 100, True, (0,0,0))
        self.draw_text(surface, "Username must not be taken", 15, 625, 150, True, (0,0,0))
        self.draw_text(surface, 'Password must be greater than 8 Characters', 15, 625, 180, True, (0,0,0))
        self.draw_text(surface, 'Password must be less than 21 Characters', 15, 625, 210, True, (0,0,0))
        self.draw_text(surface, 'Password must have an upper case', 15, 625, 240, True, (0,0,0))
        self.draw_text(surface, 'Password must have a lower case', 15, 625, 270, True, (0,0,0))
        self.draw_text(surface, 'Password must have a number', 15, 625, 300, True, (0,0,0))

        if self.tickssincepressed < 300:
            self.draw_text(surface, self.message, 15, 20, 650, True, (255,0,0))

        pygame.draw.line(surface, (0,0,0), (0,85), (1280, 85), 5)  #framing lines (design)
        pygame.draw.line(surface, (0,0,0), (620, 85), (620, 720), 5)



    def update(self):
        self.tickssincepressed += 1