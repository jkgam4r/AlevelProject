import pygame
from UIElements.UIButton import UI_Button
from UIElements.UITextbox import UI_Textbox
from screens.screen import Screen
from audio_handler import GlobalAudio
from user_functions import get_user
from data_layer import load_user, save_user

class setting_screen(Screen):
    def __init__(self, updatestate):
        super().__init__((60,60,60))


        self.update_state = updatestate

        def returntostart():
            self.update_state("START")

        def togglemusic():
            GlobalAudio.ChangeMusic()
            if get_user() != '':  #if the user is logged in
                user_dict = load_user(get_user())[1]  #then load the user dict
                user_dict["settings"]["music"] = GlobalAudio.music  #and store the state of music in the user
                save_user(user_dict) #store user dict
            
        def toggleSFX():
            GlobalAudio.ChangeSFX()
            if get_user() != '':  #if the user is logged in
                user_dict = load_user(get_user())[1]  #then load the user dict
                user_dict["settings"]["SFX"] = GlobalAudio.SFX  #and store the state of SFX in the user
                save_user(user_dict)  #store user dict


        returnbutton = UI_Button(20, 20, 150, 60, "Return", returntostart, (255,0,0), (255,255,0))
        musictoggle = UI_Button(20, 200, 200, 60, "Toggle Music", togglemusic, (255,0,0), (255,255,0))  #toggle music button
        SFXtoggle = UI_Button(20, 280, 200, 60, "Toggle SFX", toggleSFX, (255,0,0), (255,255,0))

        self.add([returnbutton, musictoggle, SFXtoggle])
    


    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen


        self.draw_text(surface, "Settings Page", 30, 180, 50, True, (0,0,0) )
        