import pygame
from UIElements.UIButton import UI_Button
from UIElements.UITextbox import UI_Textbox
from screens.screen import Screen
from data_layer import authenticate, load_user
from user_functions import set_user
from audio_handler import GlobalAudio #import global audio into this screen

class loginscreen(Screen):
    def __init__(self, updatestate):
        super().__init__((60,60,60))

        self.update_state = updatestate

        def goback():  #function to change state back to start screen
            self.update_state("EXIST/NEW")
            self.usernamebox.text = ''
            self.passwordbox.text = ''


        def login():   #this function will eventually take the text stored in existing user boxes and login/deny access user 
            username = self.usernamebox.text
            password = self.passwordbox.text
            result = authenticate(username, password) #checks whether login is valid

            self.loginmessageticks = 0 #ticks since button pressed = 0

            if result == 'SUCCESS':

                self.message = 'Login Success'  #display text 
                set_user(self.usernamebox.text) #set current user to be the username stored in the username box

                user_dict = load_user(self.usernamebox.text)  #gets the user dict

                musicstate = user_dict[1]["settings"]["music"]  #fetch user stored music state 
                SFXstate = user_dict[1]["settings"]["SFX"]  #user stored SFX state
                
                if musicstate != GlobalAudio.music:  #if the stored state is not the current state
                    GlobalAudio.ChangeMusic()  #then flip the state
                if SFXstate != GlobalAudio.SFX:  #if stored sfx not current sfx
                    GlobalAudio.ChangeSFX()   #flip sfx state

                GlobalAudio.SuccessSound() #success sound

                

            elif result == 'INVALID_INPUT':  #set error messages based on error type
                self.message = 'Invalid Input'
            elif result == 'USER_NOT_FOUND':
                self.message = 'User does not exist'
            elif result == "WRONG_PASSWORD":
                self.message = "Wrong Password"

            

        self.usernamebox = UI_Textbox(20, 180, 595, 50, "", "Enter Username", 20, False)  #current users box
        self.passwordbox = UI_Textbox(20, 280, 595, 50, "", "Enter Password", 20, True) #current user password box

        self.goback = UI_Button(20,20,150, 60, "Return", goback, (255, 0,0), (255,255,0))  #button to take user back to start screen
        self.loginbutton = UI_Button(20, 380, 595, 50, "Login", login, (255,0,0), (255, 255,0))  #button to log in existing user
    

        self.add([self.usernamebox, self.passwordbox, self.goback, self.loginbutton])

        self.message = ''  #placeholder for when login button pressed
        self.loginmessageticks = 300


    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen
        
 
        self.draw_text(surface, "Existing Users,",20, 190, 40, True, (0,0,0) )
        self.draw_text(surface, "Login Here",20, 190, 62, True, (0,0,0) )

        if self.loginmessageticks < 300:  #if the login button was pressed less that 300 ticks ago
            self.draw_text(surface, self.message, 20, 50, 650, True, (255,0,0))  #display text

    def update(self):
        self.loginmessageticks += 1  #increase ticks since button pressed by 1

    