from screens.screen import Screen
from UIElements.UIButton import UI_Button
import pygame
from UIElements.TrackDisplaySystem import TrackDisplaySystem

class TrackSelectionScreen(Screen):
    def __init__ (self, updatestate):
        super().__init__((60,60,60))

        self.update_state = updatestate

        def Return():  #function for return button
            self.update_state("START")

        def StartGame():

            if self.TrackDisplay.active_track != None: #if a track is selected
                self.update_state("GAME", self.TrackDisplay.active_track) #code for checking user login, getting track etc to be here

        def GoTrackBuilder():
            self.update_state("TRACKBUILDER")

        self.ReturnButton = UI_Button(5, 5, 120, 60, "Return", Return, (255,0,0), (255,255,0)) #create return button
        self.GameButton = UI_Button(860, 500, 400, 200, "Start Game", StartGame, (255,0,0), (255,255,0))
        self.TrackBuilderButton = UI_Button(860, 65, 400, 420, "Track Builder", GoTrackBuilder, (255,0,0), (255,255,0))

        self.TrackDisplay = TrackDisplaySystem(235, 65, 600, 635, (120,120,120))

        self.UI_LIST = [self.TrackDisplay, self.ReturnButton, self.GameButton, self.TrackBuilderButton]

    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour

        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen

        self.draw_text(surface, "Track Selection / Building Screen", 30, 140, 15, True, (0,0,0))

    def update(self):
        self.TrackDisplay.update()
        