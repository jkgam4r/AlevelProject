import pygame
from UIElements.UIButton import UI_Button
from UIElements.UITextbox import UI_Textbox
from screens.screen import Screen

class existingornewuserscreen(Screen):
    def __init__(self, updatestate):
        super().__init__((60,60,60))

        self.update_state = updatestate

        def existinguser():   #function that takes user to existing user page
            self.update_state("EXIST")

        def newuser():  #takes user to new user page
            self.update_state("NEW")

        def gostart():   #takes user back to start page
            self.update_state("START")

        self.existinguserbutton = UI_Button(20, 360, 600 ,200, "Existing User", existinguser, (255,0,0), (255,255,0))  #button to take user to existing user page
        self.newuserbutton = UI_Button(640, 360, 600, 200, "New User", newuser, (255,0,0), (255,255,0) )  #takes user to new user page
        self.returnbutton = UI_Button(20,20,150, 60, "Return", gostart, (255,0,0), (255,255,0))   #takes user back to start page

        self.add([self.existinguserbutton, self.newuserbutton, self.returnbutton])  #add all ui to screen
        
    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen

        self.draw_text(surface, "Existing User or New User?", 30, 640, 200, False, (0,0,0))  #add text
        