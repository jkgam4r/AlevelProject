import pygame
from screens.screen import Screen
from UIElements.UIButton import UI_Button

class PauseScreen(Screen):
    def __init__(self, updatestate):
        super().__init__((150,150,150)) #light gray background

        self.update_state = updatestate   
        self.prev_state = None  #stores previous screen

        def returnstart():
            self.update_state("START")

        self.returnstartbutton = UI_Button(1175, 5, 100, 60, "Start", returnstart, (255, 0,0), (255,255,0))

        self.UI_LIST = [self.returnstartbutton]

        

    def handle_keydown(self, event):
        if event.key == pygame.K_ESCAPE:  #if escape key pressed
            self.update_state(self.prev_state)  #return user to previous state / screen

    def draw(self, surface):   #polymorphism draw function
        surface.fill(self.background_colour)
        self.draw_text(surface, "Press ESC to unpause", 25, 640, 360, False, (0,0,0))  #just draws text to help user interface

        for ui in self.UI_LIST:
            ui.draw(surface)

    def set_prev(self, prev):
        self.prev_state = prev

