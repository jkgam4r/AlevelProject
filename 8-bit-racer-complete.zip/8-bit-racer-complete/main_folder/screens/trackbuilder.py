from screens.screen import Screen
from UIElements.UIButton import UI_Button
from UIElements.Tile import Tile
from UIElements.UITextbox import UI_Textbox
import os
import pygame
import json
import queue
from collections import deque
from itertools import permutations
from user_functions import get_user
from paths import ASSETS_DIR, TRACKS_DIR, MASTERLIST_FILE, project_relative, resolve_project_path


class TrackBuilder(Screen):
    def __init__(self, updatestate):
        super().__init__((60,60,60))

        self.update_state = updatestate
        
        def create_start_track(): #function that returns array of grass values
            TileTrack = []
            for y in range (36):  #loop through 36 rows
                row = []
                for x in range (64):  #and 64 units per row
                    if y == 0 or y == 35 or x == 0 or x == 63:
                        row.append(3)
                    else:
                        row.append(1)  #create placeholder grass data
                TileTrack.append(row) #34 x 10 - 33rd index, 25th index

            TileTrack[25][33] = 4
            TileTrack[26][33] = 4
            TileTrack[27][33] = 4
            TileTrack[28][33] = 4

            return TileTrack  #returns track of grass with a start/finish line indicators     

        def get_tile_array(array):
            for y in range (len(array)): #for every row
                for x in range (len(array[y])): #for each unit in each row
                    data = array[y][x]  #fetch data in unit
                    if data == 5:
                        temptile = Tile(data, x, y, ((255,255,0)), 16)
                    else:
                        temptile = Tile(data, x, y, self.tile_images[data], 16)   #create tile with data
                    array[y][x] = temptile  #store tile in tile track
            return array  #return track

        def get_tile_images():  #loads all tile images
            tile_images = {}  #empty dictionary for tile / image relationships

            folder = ASSETS_DIR / "tiles"  #get tile directory
            for file in os.listdir(folder):  #loop through each file

                path = folder / file  #gets file path of image
                
                image = pygame.image.load(str(path)).convert_alpha()  #loads image

                image = pygame.transform.scale(image, (16, 16))

                name = int(file.replace(".png", "")) #gets name of image
                tile_images[name] = image  #stores image with corresponding name
            return tile_images

        def Return():
            self.update_state("TRACKSELECT") #returns user to track selection screen
        
        def draw_tiles_to_surface(surface):
            self.track[28][33].image = (255,0,0)
            for y in range(len(self.track)): #loops through each tile
                for x in range (len(self.track[y])):
                    self.track[y][x].draw(surface) #draws tile to surface

        def handle_track_click(pos):
            mousex = pos[0]
            mousey = pos[1]

            if mousex >= 0 and mousex <= 1024 and mousey >= 70 and mousey <= 646: #checks if global mouse pos collides with track surface
                localx = pos[0]
                localy = pos[1] - 70#gets local mouse postion (because tiles drawn using local coordinates)

                gridx = localx // 16 #converts local coordinate to tile position
                gridy = localy // 16

                pygame.draw.circle(self.track_surface, (255,0,0), (localx, localy), 2)

                if gridx > 63: #ensures bounds
                    gridx = 63

                if gridy > 35:
                    gridy = 35

                if gridy < 0:
                    gridy = 0
                
                if gridx < 0:
                    gridx = 0

                if self.track[gridy][gridx].TileType != 4: #check if selected tile is a checkpoint, if not then override with active tile

                    if self.track[gridy][gridx].TileType == 5:  #checks whether overwriting a checkpoint tile
                        self.checkpoints -= 1      

                    if (self.tile_type_selected == 5 and self.checkpoints < 3) or self.tile_type_selected != 5: #if drawing checkpoint then self.checkpoints must be less than 0

                        if self.tile_type_selected == 5: #if drawing a checkpoint tile
                            self.checkpoints += 1 #incrimenet number of checkpoints

                        self.track[gridy][gridx].TileType = self.tile_type_selected
                        self.track[gridy][gridx].image = self.tile_selected_image

                        self.current_valid = False #whenever a change is made the current valid variable set to false
                        self.waypoints_dirty = True

        self.handle_track_click = handle_track_click

        self.tile_images = get_tile_images() #stores tile images within screen
        self.track = get_tile_array(create_start_track()) #creates array of tiles using start track
        self.draw_tiles_function = draw_tiles_to_surface

        self.tile_type_selected = 1 #grass tile selected
        self.tile_selected_image = self.tile_images[self.tile_type_selected] #image for grass tile

        self.track_surface = pygame.Surface(((64 * 16), (36 * 16))) #creates empty surface for track

        self.checkpoints = 0 #stores number of checkpoints

        self.current_valid = False #stores state of whether current track has been tested for a trial lap yet

        self.AI_switch = True #stores state of whether AI should be drawn / updated
        self.AI_speed = 8 #stores speed of AI (changed by buttons)

        #Tile Select functions for buttons, 0 - road, 1 - grass, 2 - offroad, 3 - barrier, 5 - checkpoint

        def SelectRoad():
            self.tile_type_selected = 0
            self.tile_selected_image = self.tile_images[0]

        def SelectOffroad():
            self.tile_type_selected = 2
            self.tile_selected_image = self.tile_images[2]

        def SelectGrass():
            self.tile_type_selected = 1
            self.tile_selected_image = self.tile_images[1]

        def SelectBarrier():
            self.tile_type_selected = 3
            self.tile_selected_image = self.tile_images[3]

        def SelectCheckpoint():
            self.tile_type_selected = 5
            self.tile_selected_image = (255,255,0)

        def LoadTrack(): #function called to load track
            track_name = self.Textbox.text #fetch track name textbox
            with open(MASTERLIST_FILE, "r") as file:
                data = json.load(file)

            tracks = data['masterlist'] #list of all tracks

            track_path = project_relative(TRACKS_DIR / (track_name + ".json")) #portable relative file path
            found = False

            for i in range (len(tracks)):
                if tracks[i] == track_path: #loop through each available track, if in list then track found
                    found = True

            if found == True:  #if the track exists
                with open(resolve_project_path(track_path), 'r') as file: #then open the track file and get the data from it
                    data = json.load(file) 
                
                track = data['track']

                self.checkpoints = 0 #gets number of checkpoints on newly loaded track
                for y in range(len(track)):
                    for x in range(len(track[y])):
                        if track[y][x] == 5:
                            self.checkpoints += 1

                self.track = get_tile_array(track) #replace current track with new track
                self.waypoints_dirty = True
                self.Textbox.text = "Track Loaded" #success text displayed in textbox

            else:
                self.Textbox.text = "Track Not Found" #text to display in textbox if track not found

        def SaveTrack(): #function called to save track

            if self.checkpoints == 3 and self.current_valid and self.check_valid() and self.Textbox.text != '':
                trackname = self.Textbox.text 
                username = get_user()
                trackdata = []

                for y in range (len(self.track)): #loops through tile track and creates 2D array of tile types (storage format)
                    row = []
                    for x in range (len(self.track[y])):
                        row.append(self.track[y][x].TileType)
                    trackdata.append(row)  

                if self.AI_switch == False: #if the ai is disabled
                    waypoints = None #then don't store waypoints
                else: #otherwise store speed and waypoints
                    waypoints = [self.AI_speed, self.waypoints]

                data = {"track" : trackdata,
                        "creator" : username,
                        "name" : trackname,
                        "AI" : waypoints,
                        "records" : []} #creates data to be stored
                
                filepath = project_relative(TRACKS_DIR / (trackname + ".json")) #portable relative file path

                with open(resolve_project_path(filepath), 'w') as file:
                    json.dump(data, file) #dumps data in json file

                self.Textbox.text = "Track Saved" #displays saved message

                #open masterfile and add the new track to the master file
                with open(MASTERLIST_FILE, "r") as file:
                    data = json.load(file) #get the current list
                if filepath not in data['masterlist']:
                    data['masterlist'].append(filepath) #add on the new track
                with open(MASTERLIST_FILE, "w") as file:
                    json.dump(data, file, indent=4) #dump the altered list to the data

            else:
                if self.Textbox.text == '': 
                    self.Textbox.text = 'Enter Track Name To Save'
                elif self.checkpoints != 3:
                    self.Textbox.text = "3 Checkpoints Needed"
                elif self.current_valid == False:
                    self.Textbox.text = "Complete Test Drive to Save"
                else:
                    self.Textbox.text = "All drivables tiles must connect"

        def get_waypoints(tile_track):
            """Build a reliable AI route through the start line and all checkpoints.

            The original left-wall traversal could collapse into a tiny loop on wider
            roads.  A shortest-path route between the fixed start tile and the three
            checkpoints works for both narrow and wide connected tracks.
            """
            valid_types = (0, 4, 5)
            rows = len(tile_track)
            columns = len(tile_track[0])
            start = (28, 33)

            checkpoints = []
            for y in range(rows):
                for x in range(columns):
                    if tile_track[y][x].TileType == 5:
                        checkpoints.append((y, x))

            if len(checkpoints) != 3 or tile_track[start[0]][start[1]].TileType not in valid_types:
                return []

            def neighbours(node):
                y, x = node
                for dy, dx in ((-1, 0), (0, 1), (1, 0), (0, -1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < rows and 0 <= nx < columns and tile_track[ny][nx].TileType in valid_types:
                        yield (ny, nx)

            def shortest_path(source, target):
                frontier = deque([source])
                previous = {source: None}
                while frontier:
                    current = frontier.popleft()
                    if current == target:
                        break
                    for nxt in neighbours(current):
                        if nxt not in previous:
                            previous[nxt] = current
                            frontier.append(nxt)

                if target not in previous:
                    return None

                path = []
                current = target
                while current is not None:
                    path.append(current)
                    current = previous[current]
                path.reverse()
                return path

            best_route = None
            for order in permutations(checkpoints):
                anchors = [start, *order, start]
                route = []
                valid_route = True
                for index in range(len(anchors) - 1):
                    segment = shortest_path(anchors[index], anchors[index + 1])
                    if segment is None:
                        valid_route = False
                        break
                    if route:
                        route.extend(segment[1:])
                    else:
                        route.extend(segment)

                if valid_route and (best_route is None or len(route) < len(best_route)):
                    best_route = route

            if not best_route:
                return []

            # Keep every tile centre.  This prevents the AI cutting across grass at
            # corners and is still small enough for a 64 x 36 track.
            return [[y, x] for y, x in best_route]

        self.get_waypoints = get_waypoints

        self.waypoints = None
        self.waypoints_dirty = True

        def update_waypoints(): #if AI toggled on then update the waypoints
            if self.AI_switch and self.waypoints_dirty:
                self.waypoints = self.get_waypoints(self.track)
                self.waypoints_dirty = False

        def draw_waypoints(): #if AI toggled on then loop through each waypoint and draw each one to the track surface
            if self.AI_switch and self.waypoints and len(self.waypoints) >= 2:
                colour = (255,0,0)
                for i in range(len(self.waypoints)-1):
                    start = (((self.waypoints[i][1] * 16) + 8), ((self.waypoints[i][0] * 16) + 8))
                    end = (((self.waypoints[i+1][1]*16)+8), ((self.waypoints[i+1][0]*16)+8))

                    pygame.draw.line(self.track_surface, colour, start, end, 2)          
                pygame.draw.line(self.track_surface, colour, ((self.waypoints[len(self.waypoints)-1][1]*16)+8,(self.waypoints[len(self.waypoints)-1][0]*16)+8), ((self.waypoints[0][1]*16)+8, (self.waypoints[0][0]*16)+8), 2)

        self.update_waypoints = update_waypoints
        self.draw_waypoints = draw_waypoints
            

        def TestDriveScreen():
            if self.checkpoints == 3: #if track has 3 checkpoints
                self.update_state("TEST_DRIVE", self.track) #when moving player to test drive track, pass in the current track
            else:
                self.Textbox.text = "3 Checkpoints Exactly"

        def GetStartNode(): #loops through track and finds first valid track, returns index coordinates of valid tile
            for y in range (len(self.track)):
                for x in range(len(self.track[y])):
                    if self.track[y][x].TileType in self.valid_types: #if tile type is in the valid types
                        return (y, x) #return position of tile
                    
        def GetAdjacent(NodePos): #node passed in as (y, x)
            Adjacent = []
            if NodePos[0] > 0: #if not on top border
                Adjacent.append((NodePos[0] - 1, NodePos[1])) #pass in node above

            if NodePos[0] < 35: #if not on bottom border
                Adjacent.append((NodePos[0] + 1, NodePos[1])) #pass in node below

            if NodePos[1] > 0: #if not on left border
                Adjacent.append((NodePos[0], NodePos[1] + 1)) #pass in left node

            if NodePos[1] < 63: #if not on right border 
                Adjacent.append((NodePos[0], NodePos[1] - 1)) #pass in right node

            return (Adjacent)

        def BFS(): #searches track using BFS and returns list of visited (connected) nodes
            StartNodePos = GetStartNode() #get the start node position
            StartNode = self.track[StartNodePos[0]][StartNodePos[1]] #gets start node using coordinates fetches from get start node function
            NodeQueue = queue.Queue() #create queue for nodes

            visited = [StartNode]
            NodeQueue.put(StartNode) #add the start node to the queue

            while not NodeQueue.empty(): #while the node queue is not empty
                current = NodeQueue.get()
                # current.image = (255,0,0)
                Adjacent = GetAdjacent((current.y, current.x)) #get list of node positions adjacent to current node
                for pos in Adjacent: #loop through each node adjacent to current node
                    if (self.track[pos[0]][pos[1]].TileType in self.valid_types) and (self.track[pos[0]][pos[1]] not in visited): #if current node valid and not visited
                        # self.track[pos[0]][pos[1]].image = (255,0,0)
                        visited.append(self.track[pos[0]][pos[1]]) #add node to visited and queue it to be searched
                        NodeQueue.put(self.track[pos[0]][pos[1]]) 
                        
            return visited

        def CheckValid():
            visited = BFS()
            all_valid = []
            for y in range (len(self.track)):
                for x in range (len(self.track[y])):
                    if self.track[y][x].TileType in self.valid_types: #loop through track and create list of all valid tiles
                        all_valid.append(self.track[y][x])
            
            for i in range (len(all_valid)): #check each valid tile, if one is not in BFS visited THEN RETURN FALSE
                if all_valid[i] not in visited:
                    return False
            return True
        
        def HelpMenu():
            self.update_state("HELP")

        def ToggleAI(): #called when toggle AI button pressed
            if self.AI_switch:
                self.AI_switch = False
                ToggleAIButton.colour = (255,0,0)
                print (self.AI_switch)
                return
            
            self.AI_switch = True
            self.waypoints_dirty = True
            ToggleAIButton.colour = (0,255,0)
            print (self.AI_switch)

        def Speed2():
            self.AI_speed = 2
            SetSpeed2Button.colour = (0,255,0)
            SetSpeed4Button.colour = (255,0,0)
            SetSpeed6Button.colour = (255,0,0)

        def Speed4():
            self.AI_speed = 4
            SetSpeed6Button.colour = (255,0,0)
            SetSpeed4Button.colour = (0,255,0)
            SetSpeed2Button.colour = (255,0,0)

        def Speed6():
            self.AI_speed = 6
            SetSpeed2Button.colour = (255,0,0)
            SetSpeed4Button.colour = (255,0,0)
            SetSpeed6Button.colour = (0,255,0)

        self.check_valid = CheckValid

        self.valid_types = (0, 4, 5)

        # self.waypoints = [(200,200), (500, 120), (550, 450), (300, 400), (200, 350)] #temporary list of points

        #Tile Select Buttons
        SelectRoadButton = UI_Button(1035, 70, 225, 80, "Road Tile", SelectRoad, (255,0,0), (255,255,0))
        SelectOffroadButton = UI_Button(1035, 160, 225, 80, "Offroad Tile", SelectOffroad, (255,0,0), (255,255,0))
        SelectGrassButton = UI_Button(1035, 250, 225, 80, "Grass Tile", SelectGrass, (255,0,0), (255,255,0))
        SelectBarrierButton = UI_Button(1035, 340, 225, 80, "Barrier Tile", SelectBarrier, (255,0,0), (255,255,0))
        SelectCheckpointButton = UI_Button(1035, 430, 225, 80, "Checkpoint Tile", SelectCheckpoint, (255,0,0), (255,255,0))

        ReturnButton = UI_Button(5,5,120,60, "Return", Return, (255,0,0), (255,255,0))
        self.Textbox = UI_Textbox(430, 655, 800, 50, "", "Input Track Name", 20, False, True)

        HelpButton = UI_Button (1035, 10, 225, 50, "HELP MENU", HelpMenu, (255,0,0), (255,255,0))

        LoadTrackButton = UI_Button(10, 655, 200, 60, "Load Track", LoadTrack, (255,0,0), (255,255,0))
        SaveTrackButton = UI_Button(220, 655, 200, 60, "Save Track", SaveTrack, (255,0,0), (255,255,0))

        TestDriveButton = UI_Button(1035, 550, 225, 80, "Test Drive", TestDriveScreen, (255,0,0), (255,255,0))

        ToggleAIButton = UI_Button(130, 5, 120, 60, "Toggle AI", ToggleAI, (0,255,0), (255,255,0))
        SetSpeed6Button = UI_Button (258,5,60,60," 6 ",Speed6,(255,0,0),(255,255,0) )
        SetSpeed4Button = UI_Button (323,5,60,60," 4 ",Speed4,(0,255,0),(255,255,0) )
        SetSpeed2Button = UI_Button (388,5,60,60," 2 ",Speed2,(255,0,0),(255,255,0) )


        self.UI_LIST = [ReturnButton, SelectRoadButton, 
                        SelectOffroadButton, SelectGrassButton, 
                        SelectBarrierButton, SelectCheckpointButton,
                        self.Textbox, LoadTrackButton, TestDriveButton, 
                        SaveTrackButton, HelpButton, ToggleAIButton,
                        SetSpeed6Button, SetSpeed4Button, SetSpeed2Button]
      

    def update(self):
        mouse_state = pygame.mouse.get_pressed()
        if mouse_state[0] == True:
            self.handle_track_click(pygame.mouse.get_pos())
        
        self.update_waypoints()

    def draw(self, surface):

        surface.fill(self.background_colour)
        pygame.draw.rect(surface, (120,120,120), (1030, 65, 240, 450)) #gray rect for button area

        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen


        self.track_surface.fill((0,0,0)) #fills surface
        self.draw_tiles_function(self.track_surface) #draws all tiles to the surface

        self.draw_waypoints()

        surface.blit(self.track_surface,(0,70)) #draws surface to screen

        pygame.draw.circle(surface, (255,0,0), pygame.mouse.get_pos(), 3) #player pointer for this page

    def set_prev(self, state):
        self.current_valid = state