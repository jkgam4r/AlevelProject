from screens.screen import Screen
from UIElements.UIButton import UI_Button

class HelpScreen(Screen):
    def __init__(self, updatestate):
        super().__init__((120,120,120))

        self.update_state = updatestate

        def Return():
            self.update_state("TRACKBUILDER")

        ReturnButton = UI_Button(5,5,120,60, "Return", Return, (255,0,0), (255,255,0))

        self.UI_LIST = [ReturnButton]

    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen

        self.draw_text(surface, "HELP MENU", 30, 680, 40, False, (255,255,255))

        self.draw_text(surface, "All drivable tiles must be connected (not including diagonals) to save a track", 15, 5, 100, True, (0,0,0))
        self.draw_text(surface, "A 'Drivable Tile' is a road, checkpoint or the start line", 15, 5, 140, True, (0,0,0))
        self.draw_text(surface, "Each track must have exactly 3 Checkpoints", 15, 5, 180, True, (0,0,0))
        self.draw_text(surface, "To save a track the creator must complete 1 trial lap", 15, 5, 200, True, (0,0,0))
        self.draw_text(surface, "The player is spawned facing west on the start line.", 15, 5, 240, True, (0,0,0))
        self.draw_text(surface, "The user must enter a track name to save a track", 15, 5, 280, True, (0,0,0))
        self.draw_text(surface, "If an old track has the same name as the one being saved, the older track is deleted", 15, 5, 320, True, (0,0,0))
        self.draw_text(surface, "Track names can be upper/lower case and include special characters/spaces", 15, 5, 360, True, (0,0,0))
        self.draw_text(surface, "To edit an existing track: enter the track name and load it, make changes to track", 15, 5, 420, True, (0,0,0))
        self.draw_text(surface, "then enter the track name again, comlpete test lap and press save", 15, 5, 440, True, (0,0,0))
        self.draw_text(surface, "Toggle AI Button - Select whether AI opponent enabled for the track being built", 15, 5, 490, True, (200,0,0))
        self.draw_text(surface, "When enabled, the red line shows the path that the CPU opponent will follow", 15, 5, 520, True, (200,0,0))
        self.draw_text(surface, "The numbered buttons all the user to select AI speed, For ref: Player speed = 6", 15, 5, 550, True, (200,0,0))