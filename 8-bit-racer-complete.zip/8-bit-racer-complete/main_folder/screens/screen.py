import pygame
from UIElements.UIButton import UI_Button
from UIElements.UITextbox import UI_Textbox
from audio_handler import GlobalAudio
from font_utils import game_font

class Screen(pygame.sprite.Sprite):
    def __init__ (self, bg_colour : tuple[int,int,int]):
        self.background_colour = bg_colour #stores background colour to be drawn later
        self.UI_LIST = []  #empty ui elements list
        self.active_textbox = None

    def add(self, lst):  #adds a list of elements to the ui list
        for element in lst:
            self.UI_LIST.append(element)

    def handle_mouse_click(self, pos):


        #get list of objects in screen, search through it top to bottom
        #if object clicked is a textbox, activate it, deactivate others
        #if object clicked is a button, deactivate textboxes, call button function, 
        #else, (background) deactivate textboxes

        clicked_element = None
        for element in reversed(self.UI_LIST):  #loop through list in reverse order
            if element.visible == True:   #if element is visible
                if element.contains_point(pos): #and collides with mouse point
                    clicked_element = element   #store what was clicked

        if clicked_element == None:   #if nothing was clicked
            self.active_textbox = None  #set there to be no active textbox
            for element in self.UI_LIST:  #loop through each element on screen
                if isinstance(element, UI_Textbox):  #check whether the element is a textbox
                    element.deactivate()  #if so then deactivate it

            GlobalAudio.clicksound() #play click sound when mouse button is clicked
            return #break from function
                

        elif isinstance(clicked_element, UI_Textbox):   #if the object that was clicked is a textbox
            self.active_textbox = clicked_element   #store it in active textbox
            for element in self.UI_LIST:  #loop through each element 
                if isinstance(element, UI_Textbox): #if the element is a textbox then check if it is the active box
                    if element == self.active_textbox: #if the box is the active one
                        element.set_active() #activate it inteernally
                    else:
                        element.deactivate() #if it is not the active one deactivate in internally

        elif isinstance(clicked_element, UI_Button):   #if the clicked element is a button
            self.active_textbox = None  #have no active box
            for element in self.UI_LIST:    #for each element on the screen
                if isinstance(element, UI_Textbox):  #if its a textbox then deactivate it
                    element.deactivate()

            clicked_element.clicked() #click button
            GlobalAudio.ButtonPress() #play sound when button pressed
        
        else:
            clicked_element.clicked()

        

    def handle_keydown(self, event):  
        if self.active_textbox != None:  #if there is an active textbox
            self.active_textbox.handle_keydown(event)  #draw it to the screen

    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen

    def draw_text(self, surf, text, size, x, y, drawfromtopleft, colour : tuple[int, int, int]):
        font = game_font(size)
        text = str(text)
        text_surface = font.render(text, True, colour)
        text_rect = text_surface.get_rect()
        if drawfromtopleft:
            text_rect.topleft = (x,y)
        else:
            text_rect.x = x - (text_rect.width / 2)
            text_rect.y = y - (text_rect.height / 2)
        surf.blit(text_surface, text_rect)

    def update(self):
        pass