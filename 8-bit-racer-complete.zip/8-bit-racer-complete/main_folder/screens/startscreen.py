from screens.screen import Screen
from UIElements.UIButton import UI_Button
from user_functions import get_user, set_user
from audio_handler import GlobalAudio

class startscreen(Screen):  #creates start screen class that inherits from 
    def __init__(self, updatestate): 
        super().__init__((60,60,60))  #sets bg colour using screen class init



        self.update_state = updatestate  #updating state method stored locally

        def gologin():
            self.update_state("EXIST/NEW")   #set the state to login and update active screen

        def start():
            self.update_state("TRACKSELECT")

        def audiotoggle():
            GlobalAudio.ChangeMusic()
            GlobalAudio.ChangeSFX()



        def gosettings():
            self.update_state("SETTINGS")

        loginbutton = UI_Button(20, 20, 150, 60, "LOGIN", gologin, (255, 0,0), (255, 255, 0))  #create login button
        startbutton = UI_Button(515, 310, 250, 100, "START", start, (255, 0,0), (255, 255,0))  #start button
        audiobutton = UI_Button(1110, 20, 150, 60, "Toggle Audio", audiotoggle, (255, 0,0), (255, 255,0)) #audio button
        settingsbutton = UI_Button(1030, 20, 60, 60, "X", gosettings, (255,0,0), (255,255,0))  #settings button

        self.add([loginbutton, startbutton, audiobutton, settingsbutton]) #add login button to ui list
        
        self.usertext = 'Current User : Not Logged in'

    def draw(self, surface):
        surface.fill(self.background_colour)   #fill the screen with bg colour
        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen

        self.draw_text(surface, "8 BIT RACER", 40, 640, 50, False, (255,0,0))

        self.draw_text(surface, "Jamie Cooper NEA  A-Level Computer Science 2026", 12, 5, 700,True,  (255, 0,0))

        if not self.UI_LIST[1].visible:
            self.draw_text(surface, "USER MUST BE LOGGED IN TO START", 30, 640, 360, False, (255,255,255)) #display text that user must log in 

        self.draw_text(surface, self.usertext, 15, 5, 600, True, (255, 255, 0))  #user logged in text

    def update(self):
        if get_user() != '':
            self.usertext = 'Current User : ' + get_user()
            if self.UI_LIST[1].visible == False: #if the start button is not visible but user has logged in
                self.UI_LIST[1].visible = True #make button visible
            self.UI_LIST[0].visible = False #if user is logged in the remove the login button
        else: 
            self.UI_LIST[1].visible = False #make start button invisible until user logged in


        

