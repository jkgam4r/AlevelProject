import pygame
import json
import os
import time
from screens.screen import Screen
from UIElements.UIButton import UI_Button
from UIElements.Tile import Tile
from entities.playerfile import Player
from entities.AI_opponent import AI_opponent
from paths import ASSETS_DIR, resolve_project_path

class GameScreen (Screen):
    def __init__(self, updatestate):
        super().__init__((0, 120, 0))

################################# TRACK FUNCTIONS ####################################################################################

        def get_tile_images():  #loads all tile images
            tile_images = {}  #empty dictionary for tile / image relationships

            folder = ASSETS_DIR / "tiles"  #get tile directory
            for file in os.listdir(folder):  #loop through each file

                path = folder / file  #gets file path of image
                image = pygame.image.load(str(path)).convert_alpha()  #loads image

                name = int(file.replace(".png", "")) #gets name of image
                tile_images[name] = image  #stores image with corresponding name
            return tile_images
 
        def create_empty_track(): #creates empty 64x36 array
            TileTrack = []
            for y in range (36):  #loop through 36 rows
                row = []
                for x in range (64):  #and 64 units per row
                    row.append(1)  #create placeholder data
                TileTrack.append(row)
            return TileTrack

        def load_track(trackpath):  #load track from track1.json (will be non-static in later prototypes)
            TRACK_PATH = resolve_project_path(trackpath)

            with open(TRACK_PATH) as file:  #open track file
                data = json.load(file) #load track dict
                track = data["track"]  #get track data
            return track
        
        self.load_track = load_track

        def create_tile_track():  #function to convert data to tiles
            for y in range (len(self.track)): #for every row
                for x in range (len(self.track[y])): #for each unit in each row
                    data = self.track[y][x]  #fetch data in unit
                    if data == 5:
                        temptile = Tile(data, x, y, ((255,255,0)))
                    else:
                        temptile = Tile(data, x, y, self.tile_images[data])   #create tile with data
                    self.empty_track[y][x] = temptile  #store tile in tile track
            return self.empty_track  #return track
        
        self.create_tile_track = create_tile_track

        def draw_all_tiles(surface): #function to draw all tiles to surface
            for y in range (len(self.tile_track)): #for each row
                for x in range (len(self.tile_track[y])): #each unit in each row
                    self.tile_track[y][x].draw(surface) #draw each unit tile to screen

        def handle_player_interactions():  #function that handles player track interactions
            tile_x = int(self.Player.x / 20)
            tile_y = int(self.Player.y / 20) #get tile co-ordinates

            tile = self.tile_track[tile_y][tile_x] #get tile from tile_track
            self.Player.current_max = self.Player.max * self.tile_properties[tile.TileType]["speedmult"] #set the player current max to a factor of the set max and the tile max multiplier

            if self.tile_properties[tile.TileType]["solid"] == True: #if the tile the player is on is solid
                self.Player.x = self.Player.old_x #move to previous x and y pos
                self.Player.y = self.Player.old_y
                self.Player.velocity = -2 * self.Player.velocity #give negative velocity

            if self.tile_properties[tile.TileType]["start/finish"] == True: #if player on start/finish tile
                if self.checkpointsuccess == 3: #and all 3 checkpoints have been reached
                    for checkpoint in self.checkpoints: #loop through each checkpoint and reset it
                        tile = self.tile_track[int(checkpoint[1]/20)][int(checkpoint[0]/20)]
                        tile.image = (255,255,0)
                    self.checkpointsuccess = 0 #checkpoints - 0
                    self.laps += 1 #and a lap has been completed


        def create_minimap(): #function to create minimap surface

            track = create_empty_track() #function made earlier to get empty track

            for y in range (len(self.track)): #for every row
                for x in range (len(self.track[y])): #for each unit in each row
                    data = self.track[y][x]  #fetch data in unit
                    temptile = Tile(data, x, y, self.tile_colours[data], 3)   #create tile with data
                    track[y][x] = temptile  #store tile in tile track
            
            minimap = pygame.Surface((192, 108)) #create empty surface
            for y in range (len(track)):
                for x in range (len(track[y])): #loop through minimap tile list
                    track[y][x].draw(minimap) #and draw each tile to the minimap surface

            return minimap #return the minimap surface

        def get_checkpoint_list(): #loop through track and get coordinates of checkpoint squares
            checkpoint_pos = []
            for y in range (len(self.track)):
                for x in range(len(self.track[y])):#loop through full track
                    if self.tile_track[y][x].TileType == 5: #if checkpoint
                        checkpoint_pos.append((self.tile_track[y][x].rect)) #store rect 

            return checkpoint_pos

        def check_checkpoints(): #loops through each checkpoint and checks whetehr the player has collided with it, if so turn green and incriment checkpoint success
            
            for checkpoint in self.checkpoints:
                tile = self.tile_track[int(checkpoint[1]/20)][int(checkpoint[0]/20)]
                if self.Player.rect.colliderect(checkpoint) and tile.image != (0,255,0): #if the checkpoint and player rect collide and the tile isnt green already (Already used)
                    self.checkpointsuccess += 1 #incriment number of successful checkpoints by 1
                    tile.image = (0,255,0) #change the checkpoint to green

        self.get_checkpoints = get_checkpoint_list
        self.create_minimap = create_minimap


        self.tile_properties = {  #stores properties of all tiles
            0 : {  #road
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : False
            },

            1 : { #grass
                "speedmult" : 0.5,
                "solid" : False,
                "start/finish" : False
            },

            2 : { #offroad
                "speedmult" : 0.3,
                "solid" : False,
                "start/finish" : False
            },

            3 : { #barrier
                "speedmult" : 1,
                "solid" : True,
                "start/finish" : False
            },

            4 : { #start/finish line
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : True
            },

            5: { #checkpoint
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : False
            }

        }

        self.tile_colours = {  #stores tile solid colour relationship
            0 : (90,90,90), #road
            1 : (0,255,0), #grass
            2 : (150, 75, 0), #offroad
            3 : (0, 0, 0), #barrier
            4 : (255,255,255), #start line
            5 : (255, 255, 0) #checkpoint
        }


        self.draw_all_tiles = draw_all_tiles  #makes draw function accessable internally

        self.track = create_empty_track()   #get track data
        self.empty_track = create_empty_track()
        self.tile_images = get_tile_images()  #creates dict of tile images
        self.tile_track = create_tile_track() #uses above 3 functions to create tile array

        player_image = pygame.image.load(str(ASSETS_DIR / 'redcar' / 'car.png')).convert_alpha()   #getting the main player image
        player_image = pygame.transform.scale(player_image, (12, 30))
        self.Player = Player(650, 570, player_image, 270) #creating instance of the player

        self.start_time = None #at start the start_time does not exist because player not on screen yet
        self.timer_started = False  
        self.output_time = "Time : 00:00:00"

        self.minimap = create_minimap()  #get the minimap surface object

        self.checkpoints = get_checkpoint_list() #returns rects of checkpoints
        self.check_checkpoints = check_checkpoints
        self.checkpointsuccess = 0 #must be 3 for lap to count

        self.laps = 0

        self.handleplayer = handle_player_interactions #store the handle player function

        self.trackpath = None
        self.AI_state = False  # safe default until a selected track is loaded

######################################################################################################################################


        self.update_state = updatestate

        def pausebutton():  #pause button function
            self.update_state("PAUSE", "GAME")

        PauseButton = UI_Button(5,5,100,45,"Pause", pausebutton, (255,0,0), (255,255,0))  #create pause button object

        self.UI_LIST = [PauseButton]  #game screen UI list

    def draw(self, surface):  #polymorphism draw function

        surface.fill(self.background_colour)   #fill the screen with bg colour

        self.draw_all_tiles(surface)  #calls function to draw all tiles to screen

        surface.blit(self.minimap, (1083, 5)) #draw minimap to screen
        pygame.draw.circle(surface, (255,0,0), (((self.Player.x * (3/20)) + 1083), (self.Player.y * (3/20)) + 5), 2) #draw a circle in the minimap player pos
        
        self.Player.draw(surface)  #calling players draw function to draw self to screen
        if self.AI_state:
            self.AI.draw(surface)

        for ui in self.UI_LIST:  #loop through each ui element
            ui.draw(surface)  #draw ui element to the screen
    
        self.draw_text(surface, ("Speed : " + str(round((20 * self.Player.velocity), 2)) + "KM/H"), 12, 25, 670, True, (0,0,0)) #speed UI
        self.draw_text(surface, self.output_time, 12, 25, 650, True, (0,0,0)) #timer UI
        self.draw_text(surface, ('Lap :' + str(self.laps)), 12, 25, 630, True, (0,0,0))
 

    def update(self): #game screen to be updated here
        self.Player.update() #update player
        self.handleplayer() #handles player track interactions

        if self.timer_started:
            self.current_time = time.time() - self.start_time #looping for current time

            minutes = int(self.current_time // 60) #getting the minutes seconds and ms
            seconds = int(self.current_time % 60)
            milliseconds = int((self.current_time - int(self.current_time)) * 100)

            self.output_time = f"Time : {minutes}:{seconds}:{milliseconds}" #formatted output time
        else:
            if self.Player.throttle != 0: #if the timer hasnt started but player throttle
                self.start_time = time.time() #get the time that thrtottle happened
                self.timer_started = True #and set that the timer has started

        self.check_checkpoints() #check all checkpoints for collison

        if self.laps == 3: #reset game
            self.laps = 0
            self.checkpoints = 0
            self.Player.x = 650
            self.Player.y =570
            self.Player.velocity = 0
            self.Player.angle = 270

            self.finish_time = self.current_time #get the ending time to be stored

            self.update_state("END", (self.trackpath, self.finish_time)) #pass the finish time and track path into the end screen 

        if self.AI_state and self.timer_started:  #check whether AI present and race started
            self.AI.update() #if AI present then update it
        
    def set_prev(self,trackpath):

        self.trackpath = trackpath

        self.track = self.load_track(trackpath) #loads track data from track path passed from track selection screen
        self.tile_track = self.create_tile_track() #creates tile track based on this
        self.checkpoints = self.get_checkpoints() #gets list of checkpoints of track new track
        self.minimap = self.create_minimap() #creates minimap based on new track

        with open(resolve_project_path(trackpath), 'r') as file: #opens track file
            data = json.load(file) #loads track data
            AI = data["AI"]

        if AI == None:
            self.AI_state = False #variable to store whether AI is in game or not
        else:
            self.AI_state = True
            self.AI = AI_opponent(270, AI[0], AI[1]) #create AI object based on stored track data

  

