import json   #get json library
import os  #os library for file accessing
import hashlib #hash library
from paths import USERS_DIR


USER_DIRECTORY = str(USERS_DIR)
os.makedirs(USER_DIRECTORY, exist_ok=True)

######################### STATUS CODES #####################################

SUCCESS = "SUCCESS"
USER_NOT_FOUND = "USER_NOT_FOUND"
WRONG_PASSWORD = "WRONG_PASSWORD"
INVALID_INPUT = "INVALID_INPUT"
USERNAME_TAKEN = "USERNAME_TAKEN"
WEAK_PASSWORD = "WEAK_PASSWROD"
CORRUPT_PROFILE = "CORRUPT_PROFILE"

######################################################################

def valid_password(password : str):  #password validation function
    
    has_upper = False   #state of uppercase
    has_lower = False  #state of lowercase
    has_number = False      #state of whether theres a number or not
    not_too_big_or_small = False  #stores state of whether the string is too big or small

    for char in password:   #loop through each character

        if char.isnumeric():   #if a character is a number
            if not has_number :  #and a number and not already been found
                has_number = True

        else:  #if a character is instead a letter 
            if not has_upper:   #if a matching character hasnt been found yet (in this case an uppercase letter)
                if char.upper() == char:  #check if it matches
                    has_upper = True  #if so then set it true - 

            if not has_lower: #check lowercase
                if char.lower() == char:
                    has_lower = True
        
    if len(password) < 21 and len(password) >= 8:  #checks password is more than 8 and less than 21 characters
        not_too_big_or_small = True

    if has_lower and has_upper and has_number and not_too_big_or_small: #if all requirements satisfied, return sucess
        return SUCCESS
    else:
        return WEAK_PASSWORD
    
def user_exists(username : str):  #  function to check whether user exists

    USER_FILE = os.path.join(USER_DIRECTORY, f'{username}.json')  #Create the path for the userfile

    if os.path.exists(USER_FILE):  #use os function, if the file exists then
        return SUCCESS   #return Success
    
    return USER_NOT_FOUND   #if the file does not exist then return USER_NOT_FOUND

def save_user(user_dict : dict):  #saves user dict to json file
    if isinstance(user_dict, dict) == False:  #if the input is not a dict
        return INVALID_INPUT  #return invalid input
    
    if "username" not in user_dict:  #checks whether username field is in dict
        return INVALID_INPUT  

    username = user_dict['username']   #get username from dict

    user_file = os.path.join(USER_DIRECTORY, f'{username}.json')  #create path for user file

    try:

        with open(user_file, "w") as file:   #open the user file in write mode
            json.dump(user_dict, file, indent=4)  #and dump the user dict in the file (indent is just to make it readable)

        return SUCCESS  #return success if no error with profile
    
    except Exception: #however if there is an error with accessing/writing to the user file

        return CORRUPT_PROFILE  #return that the file is corrupt
    
def load_user(username : str):       #loads user dict from json file
    if user_exists(username) == SUCCESS:   #if user exists
        USER_PATH = os.path.join(USER_DIRECTORY, f'{username}.json') #gets file path for user data
    
        try:
            with open(USER_PATH, 'r') as file:  #open user data file in read mode
                user_data = json.load(file)  #use json.load to get dict in python format

            if not isinstance(user_data, dict) or 'username' not in user_data:   #if the user data is not in a dict form or username is not in user data
                return [CORRUPT_PROFILE, None]  #return that profile is corrupt
        
            return [SUCCESS, user_data]  #if the data returned is valid then return success code followed by data
        
        except Exception:  #if there was an error reading the data
            return [CORRUPT_PROFILE, None]  #return corrupt profile
        
    else:  #if user does not exist
        return [USER_NOT_FOUND, None] #if user does not exist then return user not found

def hashpassword(password : str, salt : str = None): #hash password function

    if password == '':
        return [INVALID_INPUT, None]   #if no password is passed in
    
    if salt == None:
        salt = os.urandom(16)  #if a salt is not passed in then generate one

    else:
        if salt == '':
            return [INVALID_INPUT, None]  #if no salt is passed in
        

    password_bytes = password.encode('utf-8')   #convert passowrd text into bytes

    hash_object = hashlib.sha256(salt + password_bytes)   #combine salt and password

    hash_hex = hash_object.hexdigest()   #convert hash to bytes to be stored

    result = {'salt' : salt.hex(), 'hash' : hash_hex} #store these in a dict

    return [SUCCESS, result]   #return success with dict 

def create_user(username : str, password : str):  #function to create a new user file

    if not isinstance(username, str) or not isinstance(password, str): #ensures inputs are valid
    
        return INVALID_INPUT   
    
    username = username.rstrip() #remove spaces at end

    if username =='' or password =='':  #if either the username or password are empty
        
        return INVALID_INPUT
    
    if user_exists(username) == SUCCESS:  #if the username is already taken
        return USERNAME_TAKEN
    
    if valid_password(password) == WEAK_PASSWORD:  #if the password is too weak
        return WEAK_PASSWORD
    
    hashed = hashpassword(password)   #get the hash output list
    if hashed[0] != SUCCESS:   #if there is an error with hashing 
        return hashed[0]  #return the error

    user_dict = {  #create the user dict
        "username" : username,    #username 
        "password" : hashed[1],  #second param from password hash (hash/salt dict)

        "personal_records": {},
        
        "settings": {
            "music" : True,
            "SFX" : True
        }
    }

    status = save_user(user_dict)   #save the user dict to a new file

    if status != SUCCESS:
        return status
    
    return SUCCESS

def authenticate(username : str, password : str): #takes username and password, checks whether the password matches username
    username = username.rstrip()  #strip empty end spaces
    if username == '' or password == '': #check whetehr the paramaters are empty
        return INVALID_INPUT
    
    if user_exists(username) != SUCCESS:   #if the user does not exist
        return USER_NOT_FOUND
    
    user_dict = load_user(username)  #load user dict
    if user_dict[0] != SUCCESS: #if loading failed return error code
        return user_dict[0]
    
    user_pass = user_dict[1]['password']['hash']  #fetch the stored user hash
    user_stored_salt = user_dict[1]['password']['salt'] #fetch the stored salt (hex format)
    salt = bytes.fromhex(user_stored_salt)  #change salt from hex to salt
    input_pass_hash = hashpassword(str(password), salt)  #hashes input pass with stored hash

    if input_pass_hash[0] != SUCCESS:   #if the hash is not successfull
        return input_pass_hash[0] #return error code
    
    if input_pass_hash[1]['hash'] == user_pass:   #otherwise compare new hash to stored hash
        return SUCCESS  #if these match then user is authenticated
    
    return WRONG_PASSWORD  #otherwise password is wrong

def create_sample_users():
    create_user('user1', 'Password1')
    create_user('user2', 'Password2')
    create_user('user3', 'Password3')
    create_user('user4', 'Password4')
