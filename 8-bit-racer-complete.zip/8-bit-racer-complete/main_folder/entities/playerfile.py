import pygame
import math

class Player():
    def __init__(self, x, y, image, angle): #create player object using x, y and the image 

        self.x = x
        self.y = y
        self.image = image  #store these
        self.rotated_image = image

        self.rect = self.image.get_rect()  #create player rect and center it
        self.rect.center = (x, y)

        ######### movement variables ##############

        self.velocity = 0 #px/s
        self.acceleration = 0 #px/s^2
        self.angle = angle #degrees

        self.throttle = 0  #-1, 0, 1
        self.turning = 0 #-1, 0, 1
        self.turnspeed = 200 #turn speed in degrees per second

        self.tyre_wear = 1
        self.fuel = 1  #percentage of tank full

        self.drive_force = 0 #force the player drives with
        self.max = 6
        self.current_max = self.max
        
        self.dt = 1/30


        self.car_stats = {
            "mass" : 800, #kg
            "drive_force" : 1200, #force applied forwards
            "reverse_force" : -800, #force applied backwards
            "f_density" : 50 #fuel density per full tank
        }


    def draw(self, surface): #drawing self to screen
        surface.blit(self.rotated_image, self.rect)


    def update(self):  #player update function

        keys = pygame.key.get_pressed()

        if keys[pygame.K_w]:  #if the key w pressed is true
            self.throttle = 1
            self.drive_force = self.car_stats['drive_force']

        elif keys[pygame.K_s]: # if s key is true
            self.throttle = -1
            self.drive_force = self.car_stats['reverse_force']
    
        if keys[pygame.K_a]: #a key -> left
            self.turning = -1

        elif keys[pygame.K_d]: #d key -> right
            self.turning = 1

        if not keys[pygame.K_w] and not keys[pygame.K_s]: #if neither w or s are pressed then throttle = 0
            self.throttle = 0
            self.drive_force = 0

        if not keys[pygame.K_a] and not keys[pygame.K_d]: #if player not turning, save turning state as 0
            self.turning = 0

        if self.turning != 0 and abs(self.velocity) > 0.2:
            speed_factor = abs(self.velocity) / self.current_max #create a variable between 0 and 1 that represents speed % of max speed
            if speed_factor < 0.2: #cap minimum turn rate
                speed_factor = 0.2

            self.angle += self.turning * self.turnspeed * speed_factor * (1/30) #if the player is turning, add/subtract turn speed * speed factor * dt to the stored angle

        self.angle = self.angle % 360   #prevents overflow over 360

        self.acceleration = self.get_acceleration()  #uses acceleration formula

        self.old_x = self.x#stores position from previous frame within player, allows for collisions
        self.old_y = self.y

        self.velocity += self.acceleration #affect velocity by acceleration value

        if abs(self.velocity) > self.current_max: #hardcap for velocity
            if self.velocity > 0:
                self.velocity = self.current_max
            else:
                self.velocity = -(self.current_max)


        if self.acceleration > -0.1 and self.acceleration < 0.1:  #avoids small float values for acceleration
            self.acceleration = 0

        radians = (math.radians(self.angle)) #converts angle to radians

        self.x += self.velocity * math.sin(radians)  #gets change in x and y based on velocity and angle
        self.y -= self.velocity * math.cos(radians)

        if self.x < 0 or self.x > 1280 or self.y < 0 or self.y > 720:  #reset player if leaves map
            self.x = 160
            self.y = 200

        self.rotated_image = pygame.transform.rotate(self.image, -(self.angle))

        self.rect.center = (self.x, self.y) #change player rect

    def get_acceleration(self):
        res = -25 * self.velocity #get resistive forces
        force = self.drive_force * self.tyre_wear #get forward force
        mass = self.car_stats['mass'] + (self.fuel * self.car_stats['f_density']) #get mass

        return ((force + res) / mass) #return a