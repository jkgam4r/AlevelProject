xy  = (0,1)
if 0 in xy:
    print(True)
else:
    print (False)