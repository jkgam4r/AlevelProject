"""Cross-platform project paths for 8 Bit Racer.

The original project was developed on Windows and used a mixture of relative
paths and backslashes.  This module keeps all runtime data relative to the
project root so the restored project can be moved between Windows/macOS/Linux.
"""
from pathlib import Path

MAIN_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = MAIN_DIR.parent
ASSETS_DIR = PROJECT_ROOT / "assets"
DATA_DIR = PROJECT_ROOT / "data"
TRACKS_DIR = DATA_DIR / "tracks"
USERS_DIR = DATA_DIR / "users"
MASTERLIST_FILE = DATA_DIR / "masterlist.json"


def resolve_project_path(path):
    """Return an absolute Path for an absolute or project-relative path."""
    p = Path(path)
    if p.is_absolute():
        return p
    # Accept old Windows-style relative paths stored in JSON/masterlist files.
    normalized = Path(str(path).replace("\\", "/"))
    return (PROJECT_ROOT / normalized).resolve()


def project_relative(path):
    """Return a portable project-relative path string using forward slashes."""
    p = Path(path).resolve()
    try:
        return p.relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return p.as_posix()
