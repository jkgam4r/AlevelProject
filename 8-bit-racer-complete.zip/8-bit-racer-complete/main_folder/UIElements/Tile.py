import pygame

class Tile():
    def __init__(self, type, x, y, image, sidelength=20):  #take 5 parameters

        self.image = image  #store all data
        self.TileType = type
        self.x = x
        self.y = y
        self.rect = (x*sidelength, y*sidelength, sidelength, sidelength)

    def draw(self, surface):
        if isinstance(self.image, tuple): #if the image is a tuple (solid colour)
            pygame.draw.rect(surface, self.image, self.rect) #draw simple rect in that colour
        else:
            surface.blit(self.image, self.rect) #otherwise blit image onto screen over rect