
from UIElements.UIElement import UI_Element
import pygame
from font_utils import game_font

class UI_Button(UI_Element):   #create class
    def __init__(self, x, y, width, height, text, clickfunction, colour=(255, 255, 255), border_colour=(0,0,0)):  
        super().__init__(x,y,width,height,colour)  #call init from uielement
        self.text = str(text)
        self.func = clickfunction

        self.border_colour = border_colour

        self.padding_x = 10
        self.padding_y = 5

        self.maxtextheight = self.rect.height - (2 * self.padding_y)
        self.maxtextwidth = self.rect.width - (2 * self.padding_x)   #starting values for max text width and height
        
        self.font_name = None
        self.base_size = int(self.maxtextheight)        #set base size of font to the maxtextheight - ensures that it will be oversized
        self.font = game_font(self.base_size)   #creates font object
        self.text_surface = self.font.render(self.text, True, (0, 0, 0))  #renders text with font 
        self.text_rect = self.text_surface.get_rect()   #gets a rect using the rendered text - to be used in calculating correct size

        while self.text_rect.width > self.maxtextwidth:     #if the width of the text is greater than the max width allowed
            self.maxtextheight -= 5         #lower the max height
            self.base_size = int(self.maxtextheight)   #set the base size to the new lowered height 
            self.font = game_font(self.base_size)   #remake the font with new size
            self.text_surface = self.font.render(self.text, True, (0, 0, 0))
            self.text_rect = self.text_surface.get_rect()  #new smaller rect and keep looping until the width is less than the max width

        self.text_rect.center = self.rect.center  #sets the text to be in the center of the rect 


    def draw(self, surface):

        if self.visible == False:  #Visisble 
            return

        pygame.draw.rect(surface, self.colour, self.rect)  #draws rect onto surface passed in, white 
        pygame.draw.rect(surface, self.border_colour, self.rect, 2)
        surface.blit(self.text_surface, self.text_rect)

    def clicked(self):  #polymorphism, overrides uielement clicked method
        self.func()

