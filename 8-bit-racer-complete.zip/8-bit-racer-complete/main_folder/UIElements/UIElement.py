import pygame


class UI_Element(pygame.sprite.Sprite):  #declares sprite class

    def __init__(self, x : int, y : int, width : int, height : int, colour : tuple[int, int, int] = (255, 255, 255)): #takes basic rect paramaters as input 
        super().__init__()  #initialises sprite

        self.rect = pygame.Rect(x, y, width, height)  #declares rect for object using paramters passed in

        self.visible = True  #is object visible?
        self.hover = False   #is mouse hovering over object?
        self.colour = colour

    def draw(self, surface):

        if self.visible == False:
            return
        
        #temporary rect drawing for debugging
        pygame.draw.rect(surface, self.colour, self.rect)  #draws rect onto surface passed in, white 
        #temporary function to test rect 

    def update(self):
        if self.visible == False:  #If object not visible
            self.hover = False  #then set hovering false
            return   #and break from update, used for if a button goes off screen on one frame,
                    # rather than updating it it first checks whether it is still visible or not

        mouse_pos = pygame.mouse.get_pos()   #get current mouse position
        self.hover = self.rect.collidepoint(mouse_pos)   #set the hover variable to collision state between rect and mouse
        #print (self.hover)  #debugging


    def contains_point(self, pos : tuple[int, int]):   #takes x y as input
        return self.rect.collidepoint(pos) #returns whether it is a collision or not


    def clicked(self):
        pass  #will be filled in by inherited subclasses