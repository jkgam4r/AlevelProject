import pygame
import os
import json
from UIElements.TrackObject import TrackObject
from UIElements.UIElement import UI_Element
from UIElements.UIButton import UI_Button
from paths import TRACKS_DIR, MASTERLIST_FILE, project_relative, resolve_project_path


class TrackDisplaySystem(UI_Element):
    def __init__(self, x, y, width, height, bg_colour):  #(235, 65, 600, 635)

        super().__init__(x,y,width,height)

        self.bg_colour = bg_colour #stores background colour
        self.surf = pygame.Surface((width, height))#stores rect for display system 

        self.x = x
        self.y = y

        self.objects = []
        self.positions = [(5,5), (305, 5), (5, 290), (305,290)]

        self.active_track = None

        def get_tracks_list(track_folder_path): #function that returns list of all tracks
            tracks = []

            track_folder_path = resolve_project_path(track_folder_path)
            for file in sorted(os.listdir(track_folder_path), key=str.lower): #loop through each JSON file in the track folder
                if file.lower().endswith(".json"):
                    tracks.append(project_relative(track_folder_path / file)) #portable path stored in masterlist
            
            return tracks

        def write_masterlist(file_path, data): #takes data and path, writes 
            try: #try opening file
                with open(resolve_project_path(file_path), "w") as f:
                    json.dump({"masterlist": data}, f, indent=4) #writes track list to masterlist file 
                return True
            except:
                return False #if failure opening file
            
        def write_tracks_masterfile(track_folder, masterlist_file): #writes all tracks to the masterlist
            tracklist = get_tracks_list(track_folder) 
            write_masterlist(masterlist_file, tracklist)

        def load_masterfile(masterlistfile): #returns list of all tracks
            with open(resolve_project_path(masterlistfile), "r") as file:
                data = json.load(file)
            return data["masterlist"]
        
        def get_current_tracks(): #returns list of 4 track paths based on pointers
            tracks = []
            for i in range (4):
                tracks.append(self.tracks[self.get_indexes()[i]])
            return tracks

        def get_track_indexes(): #returns list of 4 indexes based on pointers
            indexes = [] 
            total = len(self.tracks) #total number of tracks

            for i in range(4):
                index = (self.leftpointer + i) % total #loops 4 times and adds each index to the indexes arary, if overflow then reset to 0
                indexes.append(index)

            return indexes
                
        def increment_pointers():
            total = len(self.tracks) #get total tracks
            self.leftpointer = (self.leftpointer + 4) % total
            self.rightpointer = (self.rightpointer + 4) % total #adjust pointers 
            self.refresh_tracks() #refresh tracks onscreen
            
        def deincrement_pointers():
            total = len(self.tracks) #get total tracks
            self.leftpointer = (self.leftpointer - 4) % total
            self.rightpointer = (self.rightpointer - 4) % total #adjust pointers
            self.refresh_tracks() #refresh tracks onscreen

        def refresh_tracks():
            self.current_tracks = self.get_tracks()  #gets the list of tracks currently onscreen

            self.objects = []

            for i in range(4): #creates objects for each of the tracks now on screen
                trackobject = TrackObject(self.positions[i][0], self.positions[i][1], self.current_tracks[i])    
                self.objects.append(trackobject)

            self.UI_LIST = [self.prev, self.next] + self.objects #refreshes the ui list for interactivity

        self.refresh_tracks = refresh_tracks

        self.get_tracks = get_current_tracks
        self.get_indexes = get_track_indexes

        self.increment = increment_pointers
        self.deincrement = deincrement_pointers

        self.write_masterfile = write_tracks_masterfile #function to write all tracks to masterfile
        self.load_masterfile = load_masterfile #load all tracks from masterfile

        self.write_masterfile(TRACKS_DIR, MASTERLIST_FILE) #whenever the object is created maintain the masterlist
        self.tracks = self.load_masterfile(MASTERLIST_FILE) #store the tracks within the object
        
        self.leftpointer = 0
        self.rightpointer = 3

        self.prev = UI_Button((5 + self.x), (580 + self.y), 280, 40, "Previous", self.deincrement, (255,0,0), (255,255,0))
        self.next = UI_Button((310 + self.x), (580 + self.y), 280, 40, "Next", self.increment, (255,0,0), (255,255,0))
        self.UI_LIST = [self.prev, self.next]

        self.current_tracks = self.get_tracks() #calls function that returns 4 tracks based on pointers

        for i in range (4): #loops through each track and draws to screen and stores within objects list
            self.objects.append(TrackObject((self.positions[i][0]), (self.positions[i][1]), self.current_tracks[i]))
            self.objects[i].draw(self.surf)
            self.UI_LIST.append(self.objects[i])

        self.total_tracks = len(self.tracks) #stores total tracks

    def draw(self, surface):
        self.surf.fill(self.bg_colour) #redraw surface each frame

        for object in self.objects:
            object.draw(self.surf) #draw each track object to the surface
        
        surface.blit(self.surf, (self.x, self.y)) #draws surface to screen

        for i in range (len(self.UI_LIST)):
            if isinstance(self.UI_LIST[i], UI_Button): #draws each button to screen
                self.UI_LIST[i].draw(surface)

    def update(self):

        for i in range (4): #update each track on screen
            self.objects[i].update()

        updated_tracks = self.load_masterfile(MASTERLIST_FILE) #gets updated masterfile each frame

        if self.total_tracks != len(updated_tracks):
            self.tracks = updated_tracks
            self.total_tracks = len(updated_tracks) #updates stored tracks and total tracks5

            self.refresh_tracks() #resets currently displayed tracks
         

    def clicked(self): #when this object clicked function

        mouse_pos = pygame.mouse.get_pos()
        mouse_x = mouse_pos[0]
        mouse_y = mouse_pos[1]
        localmousepos = (mouse_x - self.x, mouse_y - self.y) #get mouse position relative to local surface

        for i in range (len(self.UI_LIST)): #then check for collisions
            if isinstance(self.UI_LIST[i], UI_Button):
                if self.UI_LIST[i].rect.collidepoint(mouse_pos):
                    self.UI_LIST[i].clicked() #checks collision for buttons using global mouse position

            elif self.UI_LIST[i].rect.collidepoint(localmousepos): #checks collision on tracks using local mouse position
                for n in range(4): #deactivate all tracks
                    self.objects[n].active = False

                self.UI_LIST[i].clicked() #then activate the one that was clicked

                self.active_track = self.UI_LIST[i].trackpath #when object clicked, get path of track from within object and store as active track