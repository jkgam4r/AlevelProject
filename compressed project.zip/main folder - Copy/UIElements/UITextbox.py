from UIElements.UIElement import UI_Element
from audio_handler import GlobalAudio
import pygame

class UI_Textbox(UI_Element):
    def __init__(self, x,y, width, height, text : str, placeholder : str, max_length : int, is_password : bool, delonclick = False):
        super().__init__(x, y, width, height)  #sets rect and basic element params
        self.text = text
        self.active = False
        self.placeholder = placeholder
        self.max_length = max_length
        self.is_pass = is_password
        self.delete_on_click = delonclick

        self.font_name = "assets\PressStart2P-vaV7.ttf"
        self.font = pygame.font.Font(self.font_name, 24)
        self.padding = 8  #padding on text so its not stuck at the first pixel

    def set_active(self):   #function to set box active
        self.active = True
    
    def deactivate(self):  #function to deactivate box
        self.active = False

    def clicked(self, mouse_pos):
        if self.contains_point(mouse_pos):   #if box contains mouse and cliked then set it active, otherwise click was detected not on box, deactivate
            self.set_active()

        else:
            self.deactivate()

    def handle_keydown(self, event):
        if self.active == False:
            return
        
        GlobalAudio.keypress()
        
        if event.key == pygame.K_BACKSPACE: #if backspace pressed
            self.text = self.text[:-1]  #take a character off
            if self.delete_on_click == True: #if textbox set to reset whenever clicked
                self.text = '' #clear box
            return

        if event.key == pygame.K_RETURN: #if enter pressed
            self.active = False #set self false
            return
    
        character = event.unicode  #get unicode value of key pressed
        if character and character.isprintable() and len(self.text) < self.max_length:
            self.text += character


    def get_display_text(self):
        if self.text == "":  #if there is no text then display the placeholder
            return self.placeholder
        
        if self.is_pass:  #if the text box stores passwords
            return ("*" * len(self.text))  #returns starred out text
        
        return self.text   #if not a password then just display the text
    
    def get_clipped_text(self, text):
        self.max_pixels = self.rect.width - (2 * self.padding)
        while self.font.size(text)[0] > self.max_pixels: #compare text width to max
            text = text[1:]  #take the first character off
        return text
    
    def draw(self, surface):
        pygame.draw.rect(surface, (255, 255, 255), self.rect)  #draw back rect

        self.borderwidth = 3
        if self.active:   #sets border width based on activity
            self.borderwidth = 1

        pygame.draw.rect(surface, (0,0,0), self.rect, self.borderwidth)  #Draws border 

        self.colour = (120, 120, 120)  #Text colour when active 
        if self.text == "":
            self.colour = (0,0,0) #colour when placeholder text

        display_text = self.get_display_text()  #get display text
        clippedtext = self.get_clipped_text(display_text)  #clip display text
 
        text_surf = self.font.render(clippedtext, True, self.colour)  #create text surface
        x = self.rect.x + self.padding  #find x and y pos for text
        y = self.rect.y + (self.rect.height - text_surf.get_height()) // 2
        surface.blit(text_surf, (x, y)) #draw text to screen

    def get_text(self):
        return self.text