import pygame
import json
import os
from UIElements.Tile import Tile
from UIElements.UIElement import UI_Element

class TrackObject(UI_Element):
    def __init__(self, x, y, trackpath):
        width = 290
        height = 280
        self.x = x
        self.y = y

        self.trackpath = trackpath

        super().__init__(x, y, width, height)

        self.surf = pygame.Surface((width, height))  #surface for everything to be drawn on 
        self.active = False
        self.border_colour = (0,0,0)



        def load_track():
            with open (trackpath, 'r') as file: #loads raw data
                rawdata = json.load(file) #open the file and store the data

            return rawdata

        def create_empty_track(): #creates empty 64x36 array
            TileTrack = []
            for y in range (36):  #loop through 36 rows
                row = []
                for x in range (64):  #and 64 units per row
                    row.append(None)  #create placeholder data
                TileTrack.append(row)
            return TileTrack

        def create_minimap(): #function to create minimap surface

            track = create_empty_track() #function made earlier to get empty track

            tile_size = 4

            for y in range (len(self.track)): #for every row
                for x in range (len(self.track[y])): #for each unit in each row
                    data = self.track[y][x]  #fetch data in unit
                    temptile = Tile(data, x, y, self.tile_colours[data], tile_size)   #create tile with data
                    track[y][x] = temptile  #store tile in tile track
            
            minimap = pygame.Surface(((tile_size * 64) , (tile_size * 36))) #create empty surface
            for y in range (len(track)):
                for x in range (len(track[y])): #loop through minimap tile list
                    track[y][x].draw(minimap) #and draw each tile to the minimap surface

            return minimap #return the minimap surface

        self.tile_colours = {  #stores tile solid colour relationship
            0 : (90,90,90), #road
            1 : (0,255,0), #grass
            2 : (150, 75, 0), #offroad
            3 : (180, 0, 0), #barrier
            4 : (255,255,255), #start line
            5 : (255, 255, 0) #checkpoint
        }

        def draw_text(surf, text, size, x, y, drawfromtopleft, colour : tuple[int, int, int]): #draw text function from the screen class
            font = pygame.font.Font("assets\PressStart2P-vaV7.ttf", size)
            text = str(text)
            text_surface = font.render(text, True, colour)
            text_rect = text_surface.get_rect()
            if drawfromtopleft:
                text_rect.topleft = (x,y)
            else:
                text_rect.x = x - (text_rect.width / 2)
                text_rect.y = y - (text_rect.height / 2)
            surf.blit(text_surface, text_rect)
        

        self.rawdata = load_track() #load track dict
        self.track = self.rawdata["track"]

        self.image = create_minimap() #surface object
        self.track_name = self.rawdata['name']
        self.creator = self.rawdata['creator']

        if self.rawdata['AI'] == None: #get AI data
            self.AI = False
            self.AI_speed = None
        else:
            self.AI = True
            self.AI_speed = self.rawdata["AI"][0]

        self.surf.fill((120,120,120)) #makes surface light gray
        self.surf.blit(self.image, (15,25)) #and adds the minimap
        draw_text(self.surf, self.track_name, 12, 15, 10, True, (0,0,0))
        draw_text(self.surf, ("Creator :" + self.creator), 12, 15, 200, True, (0,0,0))
        
        if self.AI:
            draw_text(self.surf, 'AI Enabled', 12, 15, 230, True, (0,0,0))
            draw_text(self.surf, "AI Speed :" + str(self.AI_speed), 12, 15, 260, True, (0,0,0))
        else:
            draw_text(self.surf, "AI Disabled", 12, 15, 230, True, (0,0,0))

    
    def update(self): #changes border colour based on whether self is active
        if self.active == False:
            self.border_colour = (0,0,0)
        else:
            self.border_colour = (255,255,0)


    def draw(self, surface):
        surface.blit(self.surf, (self.x, self.y)) #draw entire surface
        pygame.draw.rect(surface, self.border_colour, (self.x, self.y, 290, 280), 2) #draw border
        

    def clicked(self):
        self.active = True



