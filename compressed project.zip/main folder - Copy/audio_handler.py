import pygame

pygame.init()

class AudioManager():

    def __init__(self):
        pygame.mixer.init()

        self.click = pygame.mixer.Sound(("assets/audio/click.wav"))  #generic click sound
        self.keysound = pygame.mixer.Sound("assets/audio/keypress.ogg") #key clicked sound
        self.success = pygame.mixer.Sound("assets/audio/confirmation.ogg")  #success sound
        self.buttonsound = pygame.mixer.Sound("assets/audio/buttonpress.ogg") #button pressed sound

        self.menu_music = pygame.mixer.music.load("assets/audio/menu_music.mp3")  #menus background music
        

        self.music = True  #variable to store global music state
        self.SFX = True   #store global SFX state

        pygame.mixer.music.play(-1)  #start playing background music

        ####################################################

    def clicksound(self):  #function to play a generic click sound
        if self.SFX:
            self.click.play()

    def keypress(self):   #play click pressed sound
        if self.SFX:
            self.keysound.play()

    def SuccessSound(self):  #play success sound
        if self.SFX:
            self.success.play()        

    def ButtonPress(self):  #play button press sound
        if self.SFX:
            self.buttonsound.play()

            ###########################################################


    def ChangeMusic(self):    #function to flip music state
        if self.music:
            self.music = False
        else:
            self.music = True

    def ChangeSFX(self):  #flip SFX state
        if self.SFX:
            self.SFX = False
        else:
            self.SFX = True

    def update(self):  #called every loop, will pause music if music variable false, otherwise play
        
        if self.music == False: #if the music is off
            pygame.mixer.music.pause() #pause audio
        else:
            if not pygame.mixer.music.get_busy():#if the music is paused
                pygame.mixer.music.unpause()  #unpause it



GlobalAudio = AudioManager()