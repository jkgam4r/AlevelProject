import pygame
from numpy import arctan2, degrees, sin, cos, radians


class AI_opponent():
    def __init__ (self, angle:float, velocity:int, waypoints:list):

        def get_screen_pos(waypoint): #function that converts waypoint tuple into screen position
            tile_size = 20
            
            screenx = (waypoint[1] * tile_size) + (tile_size / 2)
            screeny = (waypoint[0] * tile_size) + (tile_size / 2)

            return (screenx, screeny)


        self.get_screen_pos = get_screen_pos   

        self.image = pygame.image.load("assets\\AI\\blue_car.png")
        self.rotated_image = self.image
        self.rect = self.image.get_rect()

        start_pos = get_screen_pos(waypoints[0]) #gets start position based on waypoint 0
        self.rect.x = start_pos[0]
        self.rect.y = start_pos[1]


        self.velocity = velocity

        ## Start waypoint calculation ##

        self.waypoints = waypoints

        self.current_waypoint_index = 0 #list index of current waypoint
        self.next_waypoint_index = 1 #stores list index of next waypoint

        self.current_waypoint = self.waypoints[self.current_waypoint_index]
        self.next_waypoint = self.waypoints[self.next_waypoint_index]

        ## Start angle calculation ##

        current_w_x = self.current_waypoint[1]
        current_w_y = self.current_waypoint[0]

        next_w_x = self.next_waypoint[1]
        next_w_y = self.next_waypoint[0]

        x_diff = next_w_x - current_w_x #gets diffrence between current waypoint and next waypoint for x & y
        y_diff = next_w_y - current_w_y

        angle = arctan2(y_diff, x_diff) #calculates angle between waypoitns
        self.angle = degrees(angle) + 90

        def handle_waypoints():
            current_w_x = self.current_waypoint[1]
            current_w_y = self.current_waypoint[0]

            next_w_x = self.next_waypoint[1]
            next_w_y = self.next_waypoint[0]

            next_w_onscreenx = (next_w_x * 20) + 10
            next_w_onscreeny = (next_w_y * 20) + 10            

            def get_net_movement():   #function that returns net x and y movement
                if current_w_x == next_w_x: #if x movement is 0 relative to the next waypoint
                    x_movement = 0 #then net x movement is 0
                elif current_w_x > next_w_x: #if the current waypoint x is greater than the next (current is on the right)
                    x_movement = -1 #then the x movement is to the left
                else: #if movement is not left or 0 then it must be to the right
                    x_movement = 1 

                if current_w_y == next_w_y: #no y movement
                    y_movement = 0
                elif current_w_y > next_w_y: #y movement upwards
                    y_movement = -1
                else: #y movement downwards
                    y_movement = 1

                return (x_movement, y_movement)

            xy_movement = get_net_movement() #tuple that stores net x and y movement

            passed_waypoint = False #stores whether waypoint has been passed or not

            if xy_movement == (0,0): 
                passed_waypoint = True

            if 0 in xy_movement and passed_waypoint == False: #movement must be NESW
                if xy_movement[0] == 0: #x movement = 0 so check y movement only
                    if (xy_movement[1] == -1 and self.rect.y < next_w_onscreeny) or (xy_movement[1] == 1 and self.rect.y > next_w_onscreeny): #if y movement is upwards and AI above next waypoint or Y movement downwards and below next waypoint
                        passed_waypoint = True #then the AI must have passed the waypoint
                else: #y movemnet = 0, so check x movement only
                    if (xy_movement[0] == -1 and self.rect.x < next_w_onscreenx) or (xy_movement[0] == 1 and self.rect.x > next_w_onscreenx): #error -1 to 1
                        passed_waypoint = True
            else:
                if xy_movement[0] == -1: # if moving left
                    if xy_movement[1] == -1 and  (self.rect.y < next_w_onscreeny and self.rect.x < next_w_onscreenx): #(-1,-1 case so top left,)
                        passed_waypoint = True #if above waypoint and to left of waypoint, then the waypoint has been passed
                    elif xy_movement[1] == 1 and  (self.rect.y > next_w_onscreeny and self.rect.x < next_w_onscreenx): #(-1,1 case so bottom left)
                        passed_waypoint = True #if below waypoint and to left of waypoint then waypoint has been passed
                else: #must be moving right
                    if xy_movement[1] == -1 and  (self.rect.y < next_w_onscreeny and self.rect.x > next_w_onscreenx): #(1,-1 case so top right,)
                        passed_waypoint = True #if above waypoint and to left of waypoint, then the waypoint has been passed
                    elif xy_movement[1] == 1 and  (self.rect.y > next_w_onscreeny and self.rect.x > next_w_onscreenx): #(1,1 case so bottom right)
                        passed_waypoint = True #if below waypoint and to left of waypoint then waypoint has been passed

            if passed_waypoint == True: #if the waypoint was passed
                self.current_waypoint_index += 1 #incriment pointers
                self.next_waypoint_index += 1

                if self.current_waypoint_index > len(self.waypoints)-1: #check for overflow and reset if there is any
                    self.current_waypoint_index = 0

                if self.next_waypoint_index > len(self.waypoints)-1:
                    self.next_waypoint_index = 0

                self.current_waypoint = self.waypoints[self.current_waypoint_index] #then reset the pointers
                self.next_waypoint = self.waypoints[self.next_waypoint_index]

                new_pos = self.get_screen_pos(self.current_waypoint)
                self.rect.x = new_pos[0]
                self.rect.y = new_pos[1]

                ## calculate new angle ##

                current_w_x = self.current_waypoint[1]
                current_w_y = self.current_waypoint[0] #update values needed to calculate angle
                next_w_x = self.next_waypoint[1]
                next_w_y = self.next_waypoint[0]

                x_diff = next_w_x - current_w_x #gets diffrence between current waypoint and next waypoint for x & y
                y_diff = next_w_y - current_w_y

                angle = arctan2(y_diff, x_diff) #calculates angle between waypoitns
                self.angle = degrees(angle) + 90

        self.handle_waypoints = handle_waypoints #function that checks whether waypoint has been passed and updates pointers / waypoint varaibles if tehy have been

    def draw(self, screen): #draws object to surface
        screen.blit(self.rotated_image, self.rect)

    def update(self): #move, check pos relative to waypoints, update waypoints

        self.angle = self.angle % 360
        self.rotated_image = pygame.transform.rotate(self.image, -(self.angle)) #rotate image based on angle

        self.handle_waypoints()

        angleradians = radians(self.angle)
        self.rect.x += self.velocity * sin(angleradians)  #gets change in x and y based on velocity and angle
        self.rect.y -= self.velocity * cos(angleradians)

        