import pygame
from screens.startscreen import startscreen
from screens.existinguserscreen import loginscreen
from screens.existingornewuser import existingornewuserscreen
from screens.newuserscreen import newuserscreen
from screens.settingsscreen import setting_screen
from screens.gamescreen import GameScreen
from screens.pausescreen import PauseScreen
from screens.endscreen import EndScreen
from screens.trackselectionscreen import TrackSelectionScreen
from screens.trackbuilder import TrackBuilder
from screens.testdrivescreen import TestDriveScreen
from screens.helpscreen import HelpScreen


def main():  #MAIN LOOP TO ONLY BE RAN IN THIS FILE

    pygame.init()  #INITIALISE PYGAME

    width = 1280
    height = 720 #SET SCREEN SIZE 
    screen = pygame.display.set_mode((width, height)) 

    pygame.display.set_caption("8 BIT RACER - Jamie Cooper")

    fps = 31
    clock = pygame.time.Clock() #SET FPS CAP AND CREATE CLOCK

    running = True  #CREATING RUNNING VARIABLE FOR LOOP


###################################### STATE UPDATING FUNCTION ############################################

    def updatestate(newstate, prev_screen=None):
        nonlocal current_state, active_screen  #fetch state and active screen
        current_state = newstate   #set a new state
        active_screen = screens[newstate]  #set a new screen
        if prev_screen != None:   #if the previous screen variable isnt none, then the screen being updated must want to know the previous screen
            active_screen.set_prev(prev_screen)  #so call the set_prev function that passes the previous screen data into the active screen
            
###################################################### SCREENS ##########################################

    current_state = 'START'

    start_screen = startscreen(updatestate)
    existornewscreen = existingornewuserscreen(updatestate)
    login_screen = loginscreen(updatestate)
    new_user_screen = newuserscreen(updatestate) 
    settings_screen = setting_screen(updatestate)
    game_screen = GameScreen(updatestate)
    pause_screen = PauseScreen(updatestate)
    end_screen = EndScreen(updatestate)
    track_selection_screen = TrackSelectionScreen(updatestate)
    track_builder_screen = TrackBuilder(updatestate)
    test_drive_screen = TestDriveScreen(updatestate)
    help_screen = HelpScreen(updatestate)

    screens = {                      #dictionary that stores full relationships between all game states and screens,
        "START" : start_screen,        #used to set the active screen based on the state using the updatestate function.
        "EXIST/NEW" : existornewscreen,
        "NEW" : new_user_screen,
        "EXIST" : login_screen,
        "SETTINGS" : settings_screen,
        "GAME" : game_screen,
        "PAUSE": pause_screen,
        "END" : end_screen,
        "TRACKSELECT" : track_selection_screen,
        "TRACKBUILDER" : track_builder_screen,
        "TEST_DRIVE" : test_drive_screen,
        "HELP" : help_screen
        }
    
    active_screen = start_screen

################################AUDIO#####################################

    from audio_handler import GlobalAudio  #import audio here so music doesn't play while game is loading

######################################################### GAME LOOP ######################################

    while running:  #GAME LOOP

        for event in pygame.event.get():
            if event.type == pygame.QUIT:  #EVENT HANDLING
                running = False
                
            if event.type == pygame.MOUSEBUTTONDOWN:  #Checking for mouse clicks
                active_screen.handle_mouse_click(pygame.mouse.get_pos())

            if event.type == pygame.KEYDOWN:  #checking for key presses
                active_screen.handle_keydown(event)

        active_screen.update()  

        GlobalAudio.update()  #update audio each frame

        active_screen.draw(screen)

        pygame.display.flip()  #FLIP SCREEN EACH UPDATE

        clock.tick(fps) #TICK FPS INCRIMENT


if __name__ == "__main__":
    main()

pygame.quit()
