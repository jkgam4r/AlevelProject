from screens.screen import Screen
from UIElements.UIButton import UI_Button
from user_functions import get_user
import json
import pygame
import sys

class EndScreen (Screen):
    def __init__(self, update_state):
        super().__init__((60,60,60))

        self.update_state = update_state

        def returnstart():
            self.update_state("START")

        def quitbuttonfunc():
            pygame.quit()
            sys.exit()

        self.returnbutton = UI_Button(5, 5, 120, 40, "Return", returnstart, (255,0,0), (255,255,0))
        self.quitbutton = UI_Button(1215, 5, 60, 60, "X", quitbuttonfunc, (255,0,0), (0,0,0))

        self.UI_LIST = [self.returnbutton, self.quitbutton]


    def draw(self, surface):

        surface.fill(self.background_colour)

        for ui in self.UI_LIST:
            ui.draw(surface)


        self.draw_text(surface, ("Your Time was - " + str(self.player_time) + " Seconds"), 20, 640, 650, False, (225, 225, 255))
        self.draw_text(surface, ("Your Personal record is - " + str(self.player_record) + " Seconds"), 20, 640, 690, False, (200,200,200))

        self.draw_text(surface, "TOP 5 ALL TIME SCORES", 25, 640, 30, False, (255,0,0)) #tile
        for i in range (len(self.topscores)):
            self.draw_text(surface, self.topscores[i], 18, 640, (70 + (i * 30)), False, (255,0,0)) #draw the time records lowering as the list index increases

        self.draw_text(surface, "THANKS FOR PLAYING " + (self.user).upper() + '!!', 40, 640, 360, False, (0,255,0))



    def set_prev(self, data : tuple): #take data from game screen

        ## Saving new data section ##

        trackpath = data[0]
        time_taken = round(data[1], 2) #get track path, time taken and username
        user = get_user()

        with open (trackpath, 'r') as file: #load the track name
            data = json.load(file)
            trackname = data['name']
            file.close()

        player_path = 'data\\users\\' + user + '.json' #load the player records
        with open (player_path, 'r') as file:
            data = json.load(file)
            player_records = data['personal_records']
            file.close()

        if trackname not in player_records: #if the player doesn't have a time for the current track, store the current time under the current track
            player_records[trackname] = time_taken 
        else: #if the player does have a record for this track, compare them and store the higher
            old_record = player_records[trackname] #get the original record
            if old_record > time_taken: #if the new record is better 
                player_records[trackname] = time_taken #store the new one, otherwise leave the old one

        with open (player_path, 'w') as file: #open the player file in write mode
            data['personal_records'] = player_records #adjust the data for the new records
            json.dump(data, file, indent = 4) #write the player data to the file
            file.close()

        trackdata_tobesaved = [user, time_taken] #create data to be stored in track

        with open (trackpath, 'r') as file:  #loads the track data
            trackdata = json.load(file)

        if "records" not in trackdata:
            trackdata['records'] = []

        trackdata['records'].append(trackdata_tobesaved) #adds the new records to the old records
             
        with open (trackpath, "w") as file: #writes the adjusted data to the track file
            json.dump(trackdata, file)
        
        ## now load the data that is needed 

        with open (player_path, 'r') as file: #loads player data
            data = json.load(file)
        
        self.player_record = data['personal_records'][trackname] #gets the player record for the current track
        
        with open (trackpath, 'r') as file: #load track and fetch records list
            data = json.load(file)
            track_records = data['records']

        track_records.sort(key=lambda x : x[1]) #sorts the records based on the 2nd index of each unit

        if len(track_records) > 5: #if the number of items is > 5
            track_records = track_records[:5] #shorten it to just 5
        top5 = track_records #store top 5 records for the track in top5
        top5_text =[]
        for i in range (0, len(top5)): #loop through each record
            top5_text.append((top5[i][0] + ' - ' + str(top5[i][1])))

        
        self.topscores = top5_text
        self.player_time = time_taken
        self.player_record = self.player_record
        self.user = get_user()
