from screens.screen import Screen
from UIElements.UIButton import UI_Button
import os
from UIElements.Tile import Tile
import json
import pygame
from entities.playerfile import Player

class TestDriveScreen(Screen):
    def __init__(self, updatestate):
        super().__init__((120,120,120))

        self.update_state = updatestate

        def Return():
            self.update_state("TRACKBUILDER")

        returnbutton = UI_Button(5,5,120,60, "Return", Return, (255,0,0), (255,255,0))

        self.UI_LIST = [returnbutton]

    def set_prev(self, tiletrack): #function called when given paramter from previous screen
        self.setup(tiletrack)

    def setup(self, track): #set up new track and player based on track passed in
        tiletrack = track

        newtrack = [] #empty array that will store data array for tile track

        for y in range(len(tiletrack)): #loops through tile track ripping type from each tile and recreating new array 
            row = []
            for x in range(len(tiletrack[y])):
                row.append(tiletrack[y][x].TileType)
            newtrack.append(row) #newtrack stores array of data types

        tile_images = {}  #empty dictionary for tile / image relationships

        folder = os.path.join("assets", "tiles")  #get tile directory
        for file in os.listdir(folder):  #loop through each file

            path = os.path.join(folder, file)  #gets file path of image
            image = pygame.image.load(path).convert_alpha()  #loads image

            name = int(file.replace(".png", "")) #gets name of image
            tile_images[name] = image  #stores image with corresponding name

            
        for y in range (len(newtrack)): #for every row
            for x in range (len(newtrack[y])): #for each unit in each row
                data = newtrack[y][x]  #fetch data in unit
                if data == 5:
                    temptile = Tile(data, x, y, ((255,255,0)))
                else:
                    temptile = Tile(data, x, y, tile_images[data])   #create tile with data
                newtrack[y][x] = temptile  #store tile in tile track
        
        self.tile_track = newtrack

        ####################################

        ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")) #code to spawn player copied directly from gamescreen

        player_image = pygame.image.load(
        os.path.join(ROOT_DIR, 'assets', 'redcar', 'car.png')).convert_alpha() #load player data

        player_image = pygame.transform.scale(player_image, (12, 30))

        self.Player = Player(650, 550, player_image, 270) #create the player object

        self.checkpoints = []
        self.checkpointsuccess = 0 #major variables needed for game loop
        self.laps = 0

        self.tile_properties = {  #stores properties of all tiles
            
            0 : {  #road
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : False
            },

            1 : { #grass
                "speedmult" : 0.5,
                "solid" : False,
                "start/finish" : False
            },

            2 : { #offroad
                "speedmult" : 0.3,
                "solid" : False,
                "start/finish" : False
            },

            3 : { #barrier
                "speedmult" : 1,
                "solid" : True,
                "start/finish" : False
            },

            4 : { #start/finish line
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : True
            },

            5: { #checkpoint
                "speedmult" : 1,
                "solid" : False,
                "start/finish" : False
            }

        }

        def get_checkpoint_list():
            checkpoint_pos = []
            for y in range(len(self.tile_track)):
                for x in range(len(self.tile_track[y])):
                    if self.tile_track[y][x].TileType == 5:
                        checkpoint_pos.append(self.tile_track[y][x].rect)
            return checkpoint_pos
        
        self.checkpoints = get_checkpoint_list()

        def check_checkpoints():
            for checkpoint in self.checkpoints:
                tile = self.tile_track[int(checkpoint[1]/20)][int(checkpoint[0]/20)]

                if self.Player.rect.colliderect(checkpoint) and tile.image != (0,255,0):
                    self.checkpointsuccess += 1
                    tile.image = (0,255,0)

        self.check_checkpoints = check_checkpoints #store check checkpoints internally

        def handle_player_interactions():
            tile_x = int(self.Player.x / 20)
            tile_y = int(self.Player.y / 20)

            if 0 <= tile_x < 64 and 0 <= tile_y < 36:
                tile = self.tile_track[tile_y][tile_x]

                self.Player.current_max = self.Player.max * self.tile_properties[tile.TileType]["speedmult"]

                if self.tile_properties[tile.TileType]["solid"]:
                    self.Player.x = self.Player.old_x
                    self.Player.y = self.Player.old_y
                    self.Player.velocity = -2 * self.Player.velocity

                # LAP LOGIC
                if self.tile_properties[tile.TileType]["start/finish"]:
                    if self.checkpointsuccess >= len(self.checkpoints):
                        self.checkpointsuccess = 0
                        self.laps += 1

        self.handle_player_interactions = handle_player_interactions


    def update(self):
        self.Player.update()
        self.handle_player_interactions() #handle updating player and interactions
        self.check_checkpoints()

        if self.laps >= 1: #if player has completed a lap
            self.update_state("TRACKBUILDER", True) #then take player back to track builder with True


    def draw(self, surface):
        surface.fill(self.background_colour)

        #draw track
        for y in range(len(self.tile_track)):
            for x in range(len(self.tile_track[y])):
                self.tile_track[y][x].draw(surface)

        self.Player.draw(surface) #draw player

        for ui in self.UI_LIST:
            ui.draw(surface)